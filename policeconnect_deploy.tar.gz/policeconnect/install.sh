#!/bin/bash
# PoliceConnect UG — Full Stack Install
# Run as root on fresh Ubuntu 22.04
# Usage: bash install.sh
set -e

IP="185.139.230.30"
HOST="185-139-230-30.eu-fr-cloud-xip.com"
APP_DIR="/var/www/policeconnect"
SCRIPTS_DIR="$APP_DIR/scripts"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  PoliceConnect UG — Full Stack Install v2.0"
echo "  Server: $IP"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. System packages ────────────────────────────────
echo ""
echo "→ [1/9] Installing system packages..."
apt-get update -qq
apt-get install -y -qq \
  python3.11 python3.11-venv python3-pip \
  nginx postgresql postgresql-contrib \
  curl git build-essential \
  > /dev/null 2>&1

if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
  apt-get install -y -qq nodejs > /dev/null 2>&1
fi
echo "   Node $(node -v) | npm $(npm -v) | Python $(python3.11 --version)"

# ── 2. PostgreSQL ─────────────────────────────────────
echo "→ [2/9] Setting up PostgreSQL..."
systemctl start postgresql
sudo -u postgres psql -c "DROP DATABASE IF EXISTS policeconnect_db;" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS pcuser;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER pcuser WITH PASSWORD 'PConnect2026';"
sudo -u postgres psql -c "CREATE DATABASE policeconnect_db OWNER pcuser;"
echo "   Database ready"

# ── 3. App directory ──────────────────────────────────
echo "→ [3/9] Creating app structure..."
rm -rf $APP_DIR
mkdir -p $APP_DIR/{scripts,media,staticfiles,frontend/src/{api,store,pages,components}}
cp /root/policeconnect_deploy/scripts/*.sh $SCRIPTS_DIR/
cp /root/policeconnect_deploy/scripts/seed.py $SCRIPTS_DIR/
chmod +x $SCRIPTS_DIR/*.sh

# ── 4. Python venv ────────────────────────────────────
echo "→ [4/9] Installing Python packages..."
python3.11 -m venv $APP_DIR/venv
$APP_DIR/venv/bin/pip install --upgrade pip --quiet
$APP_DIR/venv/bin/pip install --quiet \
  django==4.2.16 \
  djangorestframework==3.14.0 \
  djangorestframework-simplejwt==5.3.1 \
  django-cors-headers==4.3.1 \
  django-environ==0.11.2 \
  psycopg2-binary==2.9.9 \
  Pillow==10.3.0 \
  gunicorn==21.2.0
echo "   Packages installed"

# ── 5. Django source ──────────────────────────────────
echo "→ [5/9] Writing Django source..."
export APP_DIR
bash $SCRIPTS_DIR/write_django.sh

SECRET_KEY=$(python3.11 -c "import secrets; print(secrets.token_urlsafe(50))")
cat > $APP_DIR/.env << ENV
SECRET_KEY=$SECRET_KEY
DEBUG=False
ALLOWED_HOSTS=$IP,$HOST,localhost,127.0.0.1
CORS_ALLOWED_ORIGINS=http://$IP,http://$HOST
DB_NAME=policeconnect_db
DB_USER=pcuser
DB_PASSWORD=PConnect2026
DB_HOST=localhost
DB_PORT=5432
MEDIA_ROOT=$APP_DIR/media
ENV
echo "   Django source ready"

# ── 6. Migrate & seed ─────────────────────────────────
echo "→ [6/9] Migrating & seeding..."
cd $APP_DIR
venv/bin/python manage.py migrate --no-input 2>&1 | tail -3
venv/bin/python manage.py collectstatic --no-input > /dev/null 2>&1
venv/bin/python scripts/seed.py

# ── 7. Frontend ───────────────────────────────────────
echo "→ [7/9] Building React frontend..."
export FRONT=$APP_DIR/frontend
bash $SCRIPTS_DIR/write_frontend_pkg.sh
bash $SCRIPTS_DIR/write_frontend_css.sh
bash $SCRIPTS_DIR/write_frontend_app.sh
bash $SCRIPTS_DIR/write_frontend_pages.sh
cd $APP_DIR/frontend
npm install --silent 2>&1 | tail -1
npm run build 2>&1 | tail -3
echo "   Frontend built"

# ── 8. Nginx ──────────────────────────────────────────
echo "→ [8/9] Configuring Nginx..."
cat > /etc/nginx/sites-available/policeconnect << NGINX
server {
    listen 80;
    server_name $IP $HOST;
    client_max_body_size 100M;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    location /static/ {
        alias $APP_DIR/staticfiles/;
        expires 30d;
    }
    location /media/ {
        alias $APP_DIR/media/;
    }
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;
    }
    location /django-admin/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
    location / {
        root $APP_DIR/frontend/dist;
        try_files \$uri \$uri/ /index.html;
        expires -1;
    }
}
NGINX
rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/policeconnect /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
echo "   Nginx configured"

# ── 9. Systemd ────────────────────────────────────────
echo "→ [9/9] Creating systemd service..."
cat > /etc/systemd/system/policeconnect.service << SERVICE
[Unit]
Description=PoliceConnect UG Gunicorn
After=network.target postgresql.service
Wants=postgresql.service

[Service]
User=root
WorkingDirectory=$APP_DIR
ExecStart=$APP_DIR/venv/bin/gunicorn core.wsgi:application --workers 4 --bind 127.0.0.1:8000 --timeout 120 --access-logfile /var/log/policeconnect-access.log --error-logfile /var/log/policeconnect-error.log
Restart=always
RestartSec=5
Environment=DJANGO_SETTINGS_MODULE=core.settings

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable policeconnect
systemctl restart policeconnect
sleep 4

# ── Verify ────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
systemctl is-active --quiet policeconnect && echo "  ✓ Gunicorn: RUNNING" || echo "  ✗ Gunicorn: FAILED — check: journalctl -u policeconnect -n 30"
systemctl is-active --quiet nginx         && echo "  ✓ Nginx:    RUNNING" || echo "  ✗ Nginx: FAILED"

sleep 2
RESULT=$(curl -s -X POST http://127.0.0.1:8000/api/v1/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{"email":"citizen@demo.ug","password":"Demo1234!"}' 2>/dev/null)
echo "$RESULT" | grep -q '"access"' \
  && echo "  ✓ Login API: OK" \
  || { echo "  ✗ Login API: FAILED"; echo "    $RESULT"; }

echo ""
echo "  ✓ LIVE → http://$IP"
echo ""
echo "  Demo accounts (password: Demo1234!):"
echo "    citizen@demo.ug   officer@demo.ug   officer2@demo.ug"
echo "    admin@demo.ug     rpc@demo.ug       oversight@demo.ug"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
