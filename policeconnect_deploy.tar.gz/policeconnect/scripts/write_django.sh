#!/bin/bash
# Writes all Django source files to /var/www/policeconnect
APP=$APP_DIR

mkdir -p $APP/{core,accounts,cases,evidence,stations,messaging,audit,analytics,notifications,certificates,tips,scripts,media,staticfiles}

# ── core/settings.py ──────────────────────────────────────────────────────────
cat > $APP/core/settings.py << 'EOF'
import environ, os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
env = environ.Env()
environ.Env.read_env(BASE_DIR / '.env')

SECRET_KEY = env('SECRET_KEY')
DEBUG = env.bool('DEBUG', False)
ALLOWED_HOSTS = env.list('ALLOWED_HOSTS')

INSTALLED_APPS = [
    'django.contrib.admin','django.contrib.auth','django.contrib.contenttypes',
    'django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles',
    'rest_framework','rest_framework_simplejwt','rest_framework_simplejwt.token_blacklist',
    'corsheaders',
    'accounts','cases','evidence','stations','messaging','audit',
    'analytics','notifications','certificates','tips',
]
MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
ROOT_URLCONF = 'core.urls'
TEMPLATES = [{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[],
    'APP_DIRS':True,'OPTIONS':{'context_processors':[
        'django.template.context_processors.debug','django.template.context_processors.request',
        'django.contrib.auth.context_processors.auth','django.contrib.messages.context_processors.messages',
    ]}}]
WSGI_APPLICATION = 'core.wsgi.application'
DATABASES = {'default': env.db_url('DATABASE_URL', default=
    f"postgres://{env('DB_USER')}:{env('DB_PASSWORD')}@{env('DB_HOST')}:{env('DB_PORT')}/{env('DB_NAME')}")}
AUTH_PASSWORD_VALIDATORS = [{'NAME':'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME':'django.contrib.auth.password_validation.MinimumLengthValidator'},]
LANGUAGE_CODE='en-us'; TIME_ZONE='Africa/Kampala'; USE_I18N=True; USE_TZ=True
STATIC_URL='/static/'; STATIC_ROOT=BASE_DIR/'staticfiles'
MEDIA_URL='/media/';  MEDIA_ROOT=env('MEDIA_ROOT', default=str(BASE_DIR/'media'))
DEFAULT_AUTO_FIELD='django.db.models.BigAutoField'
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES':['rest_framework_simplejwt.authentication.JWTAuthentication'],
    'DEFAULT_PERMISSION_CLASSES':['rest_framework.permissions.IsAuthenticated'],
    'DEFAULT_PAGINATION_CLASS':'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE':20,
}
from datetime import timedelta
SIMPLE_JWT = {'ACCESS_TOKEN_LIFETIME':timedelta(hours=2),'REFRESH_TOKEN_LIFETIME':timedelta(days=7),'ROTATE_REFRESH_TOKENS':True,'BLACKLIST_AFTER_ROTATION':True,}
CORS_ALLOWED_ORIGINS = env.list('CORS_ALLOWED_ORIGINS')
CORS_ALLOW_CREDENTIALS = True
EOF

# ── core/urls.py ──────────────────────────────────────────────────────────────
cat > $APP/core/urls.py << 'EOF'
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('django-admin/', admin.site.urls),
    path('api/v1/auth/',          include('accounts.urls')),
    path('api/v1/cases/',         include('cases.urls')),
    path('api/v1/evidence/',      include('evidence.urls')),
    path('api/v1/stations/',      include('stations.urls')),
    path('api/v1/messages/',      include('messaging.urls')),
    path('api/v1/audit/',         include('audit.urls')),
    path('api/v1/analytics/',     include('analytics.urls')),
    path('api/v1/notifications/', include('notifications.urls')),
    path('api/v1/certificates/',  include('certificates.urls')),
    path('api/v1/tips/',          include('tips.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
EOF

cat > $APP/core/__init__.py << 'EOF'
EOF
cat > $APP/core/wsgi.py << 'EOF'
import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
application = get_wsgi_application()
EOF
cat > $APP/manage.py << 'EOF'
#!/usr/bin/env python
import os, sys
def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
if __name__ == '__main__':
    main()
EOF

# ── accounts app ──────────────────────────────────────────────────────────────
cat > $APP/accounts/__init__.py << 'EOF'
EOF
cat > $APP/accounts/models.py << 'EOF'
import uuid
from django.db import models
from django.contrib.auth.models import User

class Role(models.TextChoices):
    CITIZEN       = 'CITIZEN',       'Citizen'
    OFFICER       = 'OFFICER',       'Police Officer'
    STATION_ADMIN = 'STATION_ADMIN', 'Station Admin'
    RPC           = 'RPC',           'Regional Police Commander'
    OVERSIGHT     = 'OVERSIGHT',     'National Oversight'

class UserProfile(models.Model):
    id               = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user             = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role             = models.CharField(max_length=20, choices=Role.choices, default=Role.CITIZEN)
    phone            = models.CharField(max_length=20, blank=True)
    national_id      = models.CharField(max_length=30, blank=True)
    station          = models.ForeignKey('stations.Station', null=True, blank=True, on_delete=models.SET_NULL, related_name='officers')
    credibility_score= models.IntegerField(default=100)
    is_active_duty   = models.BooleanField(default=True)
    badge_number     = models.CharField(max_length=20, blank=True)
    created_at       = models.DateTimeField(auto_now_add=True)

    @property
    def full_name(self): return f"{self.user.first_name} {self.user.last_name}".strip()
    def __str__(self): return f"{self.full_name} ({self.role})"
EOF

cat > $APP/accounts/serializers.py << 'EOF'
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import UserProfile

class UserProfileSerializer(serializers.ModelSerializer):
    full_name    = serializers.ReadOnlyField()
    email        = serializers.EmailField(source='user.email', read_only=True)
    station_name = serializers.CharField(source='station.name', read_only=True)
    class Meta:
        model  = UserProfile
        fields = ['id','role','phone','national_id','station','station_name',
                  'credibility_score','badge_number','full_name','email','created_at']

class RegisterSerializer(serializers.Serializer):
    email      = serializers.EmailField()
    password   = serializers.CharField(min_length=8, write_only=True)
    first_name = serializers.CharField()
    last_name  = serializers.CharField()
    phone      = serializers.CharField(required=False, default='')
    national_id= serializers.CharField(required=False, default='')

    def validate_email(self, v):
        if User.objects.filter(username=v).exists():
            raise serializers.ValidationError('Email already registered.')
        return v

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['email'], email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data['first_name'], last_name=validated_data['last_name'],
        )
        profile = UserProfile.objects.create(
            user=user, phone=validated_data.get('phone',''),
            national_id=validated_data.get('national_id',''),
        )
        return profile
EOF

cat > $APP/accounts/views.py << 'EOF'
from django.contrib.auth import authenticate
from rest_framework import status, generics
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from .models import UserProfile
from .serializers import RegisterSerializer, UserProfileSerializer

class RegisterView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        s.save()
        return Response({'detail': 'Registration successful. You can now log in.'}, status=201)

class LoginView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        email    = request.data.get('email', '').strip()
        password = request.data.get('password', '')
        user = authenticate(request, username=email, password=password)
        if not user:
            return Response({'detail': 'Invalid email or password.'}, status=401)
        if not hasattr(user, 'profile'):
            return Response({'detail': 'Account not configured. Contact admin.'}, status=403)
        refresh = RefreshToken.for_user(user)
        return Response({
            'access':  str(refresh.access_token),
            'refresh': str(refresh),
            'profile': UserProfileSerializer(user.profile).data,
        })

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        try:
            RefreshToken(request.data.get('refresh')).blacklist()
        except Exception:
            pass
        return Response({'detail': 'Logged out.'})

class ProfileView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class   = UserProfileSerializer
    def get_object(self): return self.request.user.profile

class TokenRefreshView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        from rest_framework_simplejwt.views import TokenRefreshView as BaseRefresh
        return BaseRefresh.as_view()(request._request)
EOF

cat > $APP/accounts/urls.py << 'EOF'
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views
urlpatterns = [
    path('register/',      views.RegisterView.as_view(),  name='register'),
    path('login/',         views.LoginView.as_view(),      name='login'),
    path('logout/',        views.LogoutView.as_view(),     name='logout'),
    path('me/',            views.ProfileView.as_view(),    name='me'),
    path('token/refresh/', TokenRefreshView.as_view(),     name='token-refresh'),
]
EOF

cat > $APP/accounts/admin.py << 'EOF'
from django.contrib import admin
from .models import UserProfile
admin.site.register(UserProfile)
EOF
cat > $APP/accounts/apps.py << 'EOF'
from django.apps import AppConfig
class AccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounts'
EOF

# ── stations app ──────────────────────────────────────────────────────────────
for f in __init__ admin apps; do cat > $APP/stations/$f.py << EOF
EOF
done

cat > $APP/stations/models.py << 'EOF'
import uuid
from django.db import models
class Region(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self): return self.name
class Station(models.Model):
    id      = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    code    = models.CharField(max_length=20, unique=True)
    name    = models.CharField(max_length=200)
    region  = models.ForeignKey(Region, on_delete=models.SET_NULL, null=True, related_name='stations')
    address = models.TextField(blank=True)
    phone   = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name
EOF
cat > $APP/stations/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Station, Region
class RegionSerializer(serializers.ModelSerializer):
    class Meta: model=Region; fields='__all__'
class StationSerializer(serializers.ModelSerializer):
    region_name = serializers.CharField(source='region.name', read_only=True)
    class Meta: model=Station; fields='__all__'
EOF
cat > $APP/stations/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Station
from .serializers import StationSerializer
class StationViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes=[IsAuthenticated]
    queryset=Station.objects.select_related('region').all()
    serializer_class=StationSerializer
EOF
cat > $APP/stations/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StationViewSet
router=DefaultRouter(); router.register('', StationViewSet)
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/stations/apps.py << 'EOF'
from django.apps import AppConfig
class StationsConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='stations'
EOF

# ── cases app ──────────────────────────────────────────────────────────────────
cat > $APP/cases/__init__.py << 'EOF'
EOF
cat > $APP/cases/apps.py << 'EOF'
from django.apps import AppConfig
class CasesConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='cases'
EOF
cat > $APP/cases/models.py << 'EOF'
import uuid
from django.db import models

class CaseCategory(models.TextChoices):
    THEFT          = 'THEFT',          'Theft / Robbery'
    ASSAULT        = 'ASSAULT',        'Assault / Violence'
    LAND_DISPUTE   = 'LAND_DISPUTE',   'Land Dispute'
    FRAUD          = 'FRAUD',          'Fraud / Cyber Crime'
    MISSING_PERSON = 'MISSING_PERSON', 'Missing Person'
    CORRUPTION     = 'CORRUPTION',     'Corruption / Bribery'
    SEXUAL_OFFENCE = 'SEXUAL_OFFENCE', 'Sexual Offence'
    HOMICIDE       = 'HOMICIDE',       'Homicide'
    TRAFFIC        = 'TRAFFIC',        'Traffic Incident'
    LOST_FOUND     = 'LOST_FOUND',     'Lost & Found'
    OTHER          = 'OTHER',          'Other'

class CasePriority(models.TextChoices):
    STANDARD  = 'STANDARD',  'Standard'
    URGENT    = 'URGENT',    'Urgent'
    EMERGENCY = 'EMERGENCY', 'Emergency'

class CaseStatus(models.TextChoices):
    SUBMITTED     = 'SUBMITTED',     'Submitted'
    UNDER_REVIEW  = 'UNDER_REVIEW',  'Under Review'
    VERIFIED      = 'VERIFIED',      'Verified'
    ASSIGNED      = 'ASSIGNED',      'Assigned'
    INVESTIGATING = 'INVESTIGATING', 'Investigating'
    ESCALATED     = 'ESCALATED',     'Escalated'
    CLOSED        = 'CLOSED',        'Closed'
    REJECTED      = 'REJECTED',      'Rejected'

class Case(models.Model):
    id                = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reference         = models.CharField(max_length=30, unique=True, blank=True)
    citizen           = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT, related_name='cases')
    station           = models.ForeignKey('stations.Station', on_delete=models.PROTECT, null=True, blank=True)
    assigned_officer  = models.ForeignKey('accounts.UserProfile', on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_cases')
    category          = models.CharField(max_length=20, choices=CaseCategory.choices)
    priority          = models.CharField(max_length=10, choices=CasePriority.choices, default=CasePriority.STANDARD)
    status            = models.CharField(max_length=20, choices=CaseStatus.choices, default=CaseStatus.SUBMITTED)
    title             = models.CharField(max_length=300)
    description       = models.TextField()
    incident_date     = models.DateField()
    incident_location = models.CharField(max_length=300)
    suspect_info      = models.TextField(blank=True)
    vehicle_details   = models.TextField(blank=True)
    created_at        = models.DateTimeField(auto_now_add=True)
    updated_at        = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes  = [models.Index(fields=['status']), models.Index(fields=['citizen']), models.Index(fields=['station'])]

    def save(self, *args, **kwargs):
        if not self.reference:
            from django.utils import timezone
            count = Case.objects.count() + 1
            self.reference = f"UGA-{timezone.now().year}-{count:04d}"
        HIGH = {'CORRUPTION','SEXUAL_OFFENCE','HOMICIDE','FRAUD','MISSING_PERSON'}
        if self.category in HIGH and self.priority == CasePriority.STANDARD:
            self.priority = CasePriority.URGENT
        super().save(*args, **kwargs)

    def __str__(self): return self.reference

class CaseStatusHistory(models.Model):
    case       = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='status_history')
    status     = models.CharField(max_length=20, choices=CaseStatus.choices)
    changed_by = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT)
    note       = models.TextField(blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['changed_at']
EOF

cat > $APP/cases/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Case, CaseStatusHistory

class CaseStatusHistorySerializer(serializers.ModelSerializer):
    changed_by_name = serializers.CharField(source='changed_by.full_name', read_only=True)
    class Meta:
        model  = CaseStatusHistory
        fields = ['status','note','changed_by_name','changed_at']

class CaseSerializer(serializers.ModelSerializer):
    category_display        = serializers.CharField(source='get_category_display', read_only=True)
    status_display          = serializers.CharField(source='get_status_display',   read_only=True)
    priority_display        = serializers.CharField(source='get_priority_display', read_only=True)
    citizen_name            = serializers.CharField(source='citizen.full_name',    read_only=True)
    assigned_officer_name   = serializers.CharField(source='assigned_officer.full_name', read_only=True)
    station_name            = serializers.CharField(source='station.name',         read_only=True)
    status_history          = CaseStatusHistorySerializer(many=True, read_only=True)
    days_open               = serializers.SerializerMethodField()

    def get_days_open(self, obj):
        from django.utils import timezone
        return (timezone.now() - obj.created_at).days

    class Meta:
        model  = Case
        fields = ['id','reference','category','category_display','priority','priority_display',
                  'status','status_display','title','description','incident_date','incident_location',
                  'suspect_info','vehicle_details','citizen_name','assigned_officer_name',
                  'station_name','station','days_open','status_history','created_at','updated_at']
        read_only_fields = ['reference','status']
EOF

cat > $APP/cases/views.py << 'EOF'
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Case, CaseStatusHistory, CaseStatus
from .serializers import CaseSerializer
from accounts.models import Role

class CaseViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class   = CaseSerializer

    def get_queryset(self):
        profile = self.request.user.profile
        qs = Case.objects.select_related('citizen','station','assigned_officer').prefetch_related('status_history')
        if profile.role == Role.CITIZEN:
            return qs.filter(citizen=profile)
        if profile.role == Role.OFFICER:
            return qs.filter(assigned_officer=profile)
        if profile.role == Role.STATION_ADMIN:
            return qs.filter(station=profile.station)
        return qs  # RPC, OVERSIGHT see all

    def perform_create(self, serializer):
        profile = self.request.user.profile
        case = serializer.save(citizen=profile)
        CaseStatusHistory.objects.create(case=case, status=CaseStatus.SUBMITTED, changed_by=profile, note='Case submitted by citizen')

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        case    = self.get_object()
        new_status = request.data.get('status')
        note    = request.data.get('note', '')
        profile = request.user.profile
        if new_status not in [s[0] for s in CaseStatus.choices]:
            return Response({'detail': 'Invalid status.'}, status=400)
        case.status = new_status
        case.save()
        CaseStatusHistory.objects.create(case=case, status=new_status, changed_by=profile, note=note)
        return Response(CaseSerializer(case).data)

    @action(detail=True, methods=['post'])
    def assign_officer(self, request, pk=None):
        case = self.get_object()
        officer_id = request.data.get('officer_id')
        profile = request.user.profile
        if profile.role not in [Role.STATION_ADMIN, Role.RPC, Role.OVERSIGHT]:
            return Response({'detail': 'Not authorised.'}, status=403)
        from accounts.models import UserProfile
        try:
            officer = UserProfile.objects.get(id=officer_id, role__in=[Role.OFFICER])
        except UserProfile.DoesNotExist:
            return Response({'detail': 'Officer not found.'}, status=404)
        case.assigned_officer = officer
        case.status = 'ASSIGNED'
        case.save()
        CaseStatusHistory.objects.create(case=case, status='ASSIGNED', changed_by=profile, note=f'Assigned to {officer.full_name}')
        return Response(CaseSerializer(case).data)

    @action(detail=False, methods=['get'])
    def my_queue(self, request):
        profile = request.user.profile
        qs = Case.objects.filter(assigned_officer=profile).exclude(status='CLOSED')
        return Response(CaseSerializer(qs, many=True).data)

    @action(detail=False, methods=['get'])
    def unassigned(self, request):
        profile = request.user.profile
        if profile.role not in [Role.STATION_ADMIN, Role.RPC, Role.OVERSIGHT]:
            return Response({'detail': 'Not authorised.'}, status=403)
        qs = Case.objects.filter(assigned_officer=None, status__in=['SUBMITTED','UNDER_REVIEW','VERIFIED'])
        if profile.role == Role.STATION_ADMIN:
            qs = qs.filter(station=profile.station)
        return Response(CaseSerializer(qs, many=True).data)
EOF

cat > $APP/cases/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CaseViewSet
router = DefaultRouter()
router.register('', CaseViewSet, basename='case')
urlpatterns = [path('', include(router.urls))]
EOF
cat > $APP/cases/admin.py << 'EOF'
from django.contrib import admin
from .models import Case, CaseStatusHistory
admin.site.register(Case)
admin.site.register(CaseStatusHistory)
EOF

# ── evidence app ──────────────────────────────────────────────────────────────
cat > $APP/evidence/__init__.py << 'EOF'
EOF
cat > $APP/evidence/apps.py << 'EOF'
from django.apps import AppConfig
class EvidenceConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='evidence'
EOF
cat > $APP/evidence/models.py << 'EOF'
import uuid, hashlib
from django.db import models

def evidence_path(instance, filename):
    return f"evidence/{instance.case.id}/{uuid.uuid4()}/{filename}"

class Evidence(models.Model):
    class FileType(models.TextChoices):
        IMAGE='IMAGE','Image'; VIDEO='VIDEO','Video'
        AUDIO='AUDIO','Audio'; DOCUMENT='DOCUMENT','Document'; OTHER='OTHER','Other'

    id            = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    case          = models.ForeignKey('cases.Case', on_delete=models.PROTECT, related_name='evidence')
    uploaded_by   = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT)
    file          = models.FileField(upload_to=evidence_path, blank=True)
    original_name = models.CharField(max_length=255)
    file_size     = models.BigIntegerField(default=0)
    mime_type     = models.CharField(max_length=100, blank=True)
    file_type     = models.CharField(max_length=10, choices=FileType.choices, default=FileType.OTHER)
    sha256_hash   = models.CharField(max_length=64, blank=True)
    is_active     = models.BooleanField(default=True)
    uploaded_at   = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.file and not self.sha256_hash:
            h = hashlib.sha256()
            for chunk in self.file.chunks(): h.update(chunk)
            self.sha256_hash = h.hexdigest()
            self.file_size   = self.file.size
        super().save(*args, **kwargs)
EOF
cat > $APP/evidence/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Evidence
class EvidenceSerializer(serializers.ModelSerializer):
    uploaded_by_name = serializers.CharField(source='uploaded_by.full_name', read_only=True)
    class Meta:
        model  = Evidence
        fields = ['id','case','original_name','file','file_type','sha256_hash','file_size','is_active','uploaded_by_name','uploaded_at']
        read_only_fields=['sha256_hash','file_size','uploaded_by']
EOF
cat > $APP/evidence/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Evidence
from .serializers import EvidenceSerializer
class EvidenceViewSet(viewsets.ModelViewSet):
    permission_classes=[IsAuthenticated]
    serializer_class=EvidenceSerializer
    def get_queryset(self):
        qs=Evidence.objects.select_related('uploaded_by','case')
        case_id=self.request.query_params.get('case')
        if case_id: qs=qs.filter(case=case_id)
        return qs
    def perform_create(self, serializer):
        serializer.save(uploaded_by=self.request.user.profile)
EOF
cat > $APP/evidence/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EvidenceViewSet
router=DefaultRouter(); router.register('', EvidenceViewSet, basename='evidence')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/evidence/admin.py << 'EOF'
from django.contrib import admin
from .models import Evidence
admin.site.register(Evidence)
EOF

# ── messaging app ─────────────────────────────────────────────────────────────
cat > $APP/messaging/__init__.py << 'EOF'
EOF
cat > $APP/messaging/apps.py << 'EOF'
from django.apps import AppConfig
class MessagingConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='messaging'
EOF
cat > $APP/messaging/models.py << 'EOF'
import uuid
from django.db import models
class Message(models.Model):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    case       = models.ForeignKey('cases.Case', on_delete=models.CASCADE, related_name='messages')
    sender     = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT)
    content    = models.TextField()
    is_read    = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['created_at']
EOF
cat > $APP/messaging/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Message
class MessageSerializer(serializers.ModelSerializer):
    sender_name = serializers.CharField(source='sender.full_name', read_only=True)
    sender_role = serializers.CharField(source='sender.role', read_only=True)
    class Meta:
        model=Message; fields=['id','case','sender_name','sender_role','content','is_read','created_at']
        read_only_fields=['sender']
EOF
cat > $APP/messaging/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Message
from .serializers import MessageSerializer
class MessageViewSet(viewsets.ModelViewSet):
    permission_classes=[IsAuthenticated]
    serializer_class=MessageSerializer
    def get_queryset(self):
        qs=Message.objects.select_related('sender')
        case_id=self.request.query_params.get('case')
        if case_id: qs=qs.filter(case=case_id)
        return qs
    def perform_create(self, s): s.save(sender=self.request.user.profile)
EOF
cat > $APP/messaging/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MessageViewSet
router=DefaultRouter(); router.register('', MessageViewSet, basename='message')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/messaging/admin.py << 'EOF'
from django.contrib import admin
from .models import Message
admin.site.register(Message)
EOF

# ── audit app ─────────────────────────────────────────────────────────────────
cat > $APP/audit/__init__.py << 'EOF'
EOF
cat > $APP/audit/apps.py << 'EOF'
from django.apps import AppConfig
class AuditConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='audit'
EOF
cat > $APP/audit/models.py << 'EOF'
import uuid
from django.db import models
class AuditLog(models.Model):
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    actor       = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT, null=True, blank=True)
    action      = models.CharField(max_length=100)
    target_type = models.CharField(max_length=50, blank=True)
    target_id   = models.CharField(max_length=100, blank=True)
    detail      = models.JSONField(default=dict)
    ip_address  = models.GenericIPAddressField(null=True, blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['-created_at']
EOF
cat > $APP/audit/serializers.py << 'EOF'
from rest_framework import serializers
from .models import AuditLog
class AuditLogSerializer(serializers.ModelSerializer):
    actor_name = serializers.CharField(source='actor.full_name', read_only=True)
    actor_role = serializers.CharField(source='actor.role', read_only=True)
    class Meta: model=AuditLog; fields='__all__'
EOF
cat > $APP/audit/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import AuditLog
from .serializers import AuditLogSerializer
from accounts.models import Role
class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes=[IsAuthenticated]
    serializer_class=AuditLogSerializer
    def get_queryset(self):
        profile=self.request.user.profile
        if profile.role not in [Role.STATION_ADMIN,Role.RPC,Role.OVERSIGHT]:
            return AuditLog.objects.none()
        return AuditLog.objects.select_related('actor').all()[:200]
EOF
cat > $APP/audit/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AuditLogViewSet
router=DefaultRouter(); router.register('', AuditLogViewSet, basename='audit')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/audit/admin.py << 'EOF'
from django.contrib import admin
from .models import AuditLog
admin.site.register(AuditLog)
EOF

# ── analytics, notifications, certificates, tips (minimal stubs) ──────────────
for app in analytics notifications certificates tips; do
  cat > $APP/$app/__init__.py << 'EOF'
EOF
  cat > $APP/$app/apps.py << EOF
from django.apps import AppConfig
class ${app^}Config(AppConfig):
    default_auto_field='django.db.models.BigAutoField'; name='$app'
EOF
  cat > $APP/$app/admin.py << 'EOF'
EOF
  cat > $APP/$app/models.py << 'EOF'
EOF
  cat > $APP/$app/views.py << 'EOF'
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
class OverviewView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self, request):
        return Response({'status':'ok'})
EOF
  cat > $APP/$app/urls.py << 'EOF'
from django.urls import path
from .views import OverviewView
urlpatterns=[path('', OverviewView.as_view())]
EOF
done

# Analytics proper view
cat > $APP/analytics/views.py << 'EOF'
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from cases.models import Case, CaseStatus, CaseCategory
from django.db.models import Count

class OverviewView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self, request):
        total  = Case.objects.count()
        open_c = Case.objects.exclude(status=CaseStatus.CLOSED).count()
        closed = Case.objects.filter(status=CaseStatus.CLOSED).count()
        escal  = Case.objects.filter(status=CaseStatus.ESCALATED).count()
        by_cat = list(Case.objects.values('category').annotate(count=Count('id')).order_by('-count'))
        return Response({'total':total,'open':open_c,'closed':closed,'escalated':escal,'by_category':by_cat})
EOF
cat > $APP/analytics/urls.py << 'EOF'
from django.urls import path
from .views import OverviewView
urlpatterns=[path('overview/', OverviewView.as_view())]
EOF

# Certificates model
cat > $APP/certificates/models.py << 'EOF'
import uuid
from django.db import models
class ConductCertificate(models.Model):
    class Status(models.TextChoices):
        PENDING  = 'PENDING',  'Pending'
        APPROVED = 'APPROVED', 'Approved'
        REJECTED = 'REJECTED', 'Rejected'
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    applicant   = models.ForeignKey('accounts.UserProfile', on_delete=models.PROTECT, related_name='certificates')
    purpose     = models.CharField(max_length=200)
    status      = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    reviewed_by = models.ForeignKey('accounts.UserProfile', on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_certs')
    notes       = models.TextField(blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    class Meta: ordering=['-created_at']
EOF
cat > $APP/certificates/serializers.py << 'EOF'
from rest_framework import serializers
from .models import ConductCertificate
class CertSerializer(serializers.ModelSerializer):
    applicant_name  = serializers.CharField(source='applicant.full_name', read_only=True)
    reviewed_by_name= serializers.CharField(source='reviewed_by.full_name', read_only=True)
    class Meta:
        model=ConductCertificate
        fields=['id','purpose','status','notes','applicant_name','reviewed_by_name','created_at','updated_at']
        read_only_fields=['status','reviewed_by']
EOF
cat > $APP/certificates/views.py << 'EOF'
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import ConductCertificate
from .serializers import CertSerializer
from accounts.models import Role
class CertViewSet(viewsets.ModelViewSet):
    permission_classes=[IsAuthenticated]
    serializer_class=CertSerializer
    def get_queryset(self):
        p=self.request.user.profile
        if p.role==Role.CITIZEN: return ConductCertificate.objects.filter(applicant=p)
        return ConductCertificate.objects.all()
    def perform_create(self, s): s.save(applicant=self.request.user.profile)
    @action(detail=True, methods=['post'])
    def review(self, request, pk=None):
        cert=self.get_object()
        p=request.user.profile
        if p.role not in [Role.STATION_ADMIN,Role.RPC,Role.OVERSIGHT]:
            return Response({'detail':'Not authorised.'},status=403)
        cert.status=request.data.get('status',cert.status)
        cert.notes=request.data.get('notes',''); cert.reviewed_by=p; cert.save()
        return Response(CertSerializer(cert).data)
EOF
cat > $APP/certificates/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CertViewSet
router=DefaultRouter(); router.register('', CertViewSet, basename='certificate')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/certificates/admin.py << 'EOF'
from django.contrib import admin
from .models import ConductCertificate
admin.site.register(ConductCertificate)
EOF

# notifications model
cat > $APP/notifications/models.py << 'EOF'
import uuid
from django.db import models
class Notification(models.Model):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipient  = models.ForeignKey('accounts.UserProfile', on_delete=models.CASCADE, related_name='notifications')
    title      = models.CharField(max_length=200)
    body       = models.TextField()
    is_read    = models.BooleanField(default=False)
    case       = models.ForeignKey('cases.Case', on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['-created_at']
EOF
cat > $APP/notifications/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Notification
class NotificationSerializer(serializers.ModelSerializer):
    class Meta: model=Notification; fields='__all__'
EOF
cat > $APP/notifications/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Notification
from .serializers import NotificationSerializer
class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes=[IsAuthenticated]
    serializer_class=NotificationSerializer
    def get_queryset(self): return Notification.objects.filter(recipient=self.request.user.profile)
EOF
cat > $APP/notifications/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NotificationViewSet
router=DefaultRouter(); router.register('', NotificationViewSet, basename='notification')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/notifications/admin.py << 'EOF'
from django.contrib import admin
from .models import Notification
admin.site.register(Notification)
EOF

# Tips (anonymous tips)
cat > $APP/tips/models.py << 'EOF'
import uuid
from django.db import models
class Tip(models.Model):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    content    = models.TextField()
    category   = models.CharField(max_length=50, blank=True)
    location   = models.CharField(max_length=200, blank=True)
    is_reviewed= models.BooleanField(default=False)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['-created_at']
EOF
cat > $APP/tips/serializers.py << 'EOF'
from rest_framework import serializers
from .models import Tip
class TipSerializer(serializers.ModelSerializer):
    class Meta: model=Tip; fields=['id','content','category','location','created_at']; read_only_fields=['is_reviewed']
EOF
cat > $APP/tips/views.py << 'EOF'
from rest_framework import viewsets
from rest_framework.permissions import AllowAny
from .models import Tip
from .serializers import TipSerializer
class TipViewSet(viewsets.ModelViewSet):
    permission_classes=[AllowAny]
    serializer_class=TipSerializer
    http_method_names=['get','post','head','options']
    def get_queryset(self): return Tip.objects.none() if self.request.user.is_anonymous else Tip.objects.all()
    def perform_create(self, s): s.save(ip_address=self.request.META.get('REMOTE_ADDR'))
EOF
cat > $APP/tips/urls.py << 'EOF'
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TipViewSet
router=DefaultRouter(); router.register('', TipViewSet, basename='tip')
urlpatterns=[path('', include(router.urls))]
EOF
cat > $APP/tips/admin.py << 'EOF'
from django.contrib import admin
from .models import Tip
admin.site.register(Tip)
EOF

echo "Django source files written."
