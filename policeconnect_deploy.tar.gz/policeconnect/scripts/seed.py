#!/usr/bin/env python3
import os, sys
sys.path.insert(0, '/var/www/policeconnect')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
import django; django.setup()

from django.contrib.auth.models import User
from accounts.models import UserProfile, Role
from stations.models import Station, Region
from cases.models import Case, CaseStatusHistory, CaseStatus, CaseCategory

# ── Regions ───────────────────────────────────────────
central,  _ = Region.objects.get_or_create(name='Central Region')
northern, _ = Region.objects.get_or_create(name='Northern Region')
eastern,  _ = Region.objects.get_or_create(name='Eastern Region')
western,  _ = Region.objects.get_or_create(name='Western Region')

# ── Stations ──────────────────────────────────────────
kcp,  _ = Station.objects.get_or_create(code='KCP',  defaults=dict(name='Kampala Central Police Station', region=central, address='Kampala Road, Kampala', phone='0414-256070'))
katwe,_ = Station.objects.get_or_create(code='KTW',  defaults=dict(name='Katwe Police Station', region=central, address='Katwe, Kampala'))
gulu, _ = Station.objects.get_or_create(code='GCP',  defaults=dict(name='Gulu Central Police Station', region=northern, address='Gulu Main Road'))
jinja,_ = Station.objects.get_or_create(code='JPS',  defaults=dict(name='Jinja Police Station', region=eastern, address='Jinja Road'))
mbar, _ = Station.objects.get_or_create(code='MPS',  defaults=dict(name='Mbarara Police Station', region=western, address='Mbarara Town'))

# ── Demo Users ────────────────────────────────────────
USERS = [
    ('citizen@demo.ug',   'Namukasa',  'Sarah',   'Demo1234!', Role.CITIZEN,       '+256700111001', None,  ''),
    ('officer@demo.ug',   'Okello',    'James',   'Demo1234!', Role.OFFICER,        '+256700111002', kcp,   'KCP-4412'),
    ('officer2@demo.ug',  'Nalwoga',   'Rose',    'Demo1234!', Role.OFFICER,        '+256700111006', kcp,   'KCP-4413'),
    ('admin@demo.ug',     'Byarugaba', 'Fred',    'Demo1234!', Role.STATION_ADMIN,  '+256700111003', kcp,   'KCP-0021'),
    ('rpc@demo.ug',       'Atim',      'Grace',   'Demo1234!', Role.RPC,            '+256700111004', kcp,   'RPC-001'),
    ('oversight@demo.ug', 'Ssemanda',  'John',    'Demo1234!', Role.OVERSIGHT,      '+256700111005', None,  'OVS-001'),
]

profiles = {}
for email, ln, fn, pw, role, phone, station, badge in USERS:
    user, created = User.objects.get_or_create(username=email, defaults=dict(
        email=email, first_name=fn, last_name=ln))
    if created:
        user.set_password(pw); user.save()
    profile, _ = UserProfile.objects.get_or_create(user=user, defaults=dict(
        role=role, phone=phone, station=station, badge_number=badge))
    profiles[email] = profile
    status = 'NEW' if created else 'EXISTS'
    print(f"  {status} [{role}] {email}")

# ── Sample Cases ──────────────────────────────────────
citizen = profiles['citizen@demo.ug']
officer = profiles['officer@demo.ug']

CASES = [
    ('THEFT',    'Theft at Nakasero Market', 'My mobile phone and wallet were stolen at Nakasero Market while shopping. Suspect was a young male, brown jacket, approximately 20 years old. Happened around 2pm on the market stairs.', '2026-05-14', 'Nakasero Market, Kampala', 'INVESTIGATING', officer),
    ('LAND_DISPUTE', 'Land encroachment — Bwaise', 'Neighbour has built a fence 3 metres into my registered land. I have the land title. He refuses to remove the fence and is threatening me.', '2026-04-02', 'Bwaise III, Kampala', 'ASSIGNED', officer),
    ('FRAUD',    'Online fraud — Mobile Money scam', 'I was tricked into sending UGX 500,000 via MTN Mobile Money to a fraudster posing as a NSSF officer. I have the transaction receipt and the phone number used.', '2026-03-15', 'Ntinda, Kampala', 'SUBMITTED', None),
]

for cat, title, desc, date, loc, stat, assigned in CASES:
    if not Case.objects.filter(citizen=citizen, title=title).exists():
        case = Case.objects.create(
            citizen=citizen, station=kcp, category=cat,
            title=title, description=desc,
            incident_date=date, incident_location=loc,
        )
        if assigned:
            case.assigned_officer = assigned
        case.status = stat
        case.save()
        CaseStatusHistory.objects.create(case=case, status=CaseStatus.SUBMITTED, changed_by=citizen, note='Filed by citizen')
        if stat != 'SUBMITTED':
            CaseStatusHistory.objects.create(case=case, status=stat, changed_by=officer, note='Status updated by officer')
        print(f"  CASE [{cat}] {case.reference}")

print("\nSeed complete.")
