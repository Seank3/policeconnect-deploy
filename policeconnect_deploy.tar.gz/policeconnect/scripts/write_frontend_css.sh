#!/bin/bash
# Writes all React source files
FRONT=/var/www/policeconnect/frontend/src

# ── main.jsx ──────────────────────────────────────────────────────────────────
cat > $FRONT/main.jsx << 'EOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)
EOF

# ── index.css ─────────────────────────────────────────────────────────────────
cat > $FRONT/index.css << 'CSSEOF'
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --navy:#12122a;--navy2:#1c1c3a;--navy3:#252550;
  --gold:#FCDC04;--red:#D21034;--white:#ffffff;
  --ink:#e8e6de;--ink2:#aaa89e;--ink3:#6a6860;
  --surface:#1c1c3a;--surface2:#252550;--surface3:#1a1a40;
  --border:rgba(255,255,255,0.08);--border2:rgba(255,255,255,0.04);
  --green:#2ecc80;--green-bg:rgba(46,204,128,0.12);
  --blue:#5b8ef0;--blue-bg:rgba(91,142,240,0.12);
  --amber:#e0921a;--amber-bg:rgba(224,146,26,0.12);
  --red-bg:rgba(210,16,52,0.12);
  --radius:10px;--radius-sm:6px;--sidebar-w:230px;
  --font:'Helvetica Neue',Arial,sans-serif;
}
body{font-family:var(--font);background:var(--navy);color:var(--ink);font-size:14px;line-height:1.5;min-height:100vh;-webkit-font-smoothing:antialiased}
.shell{display:grid;grid-template-columns:var(--sidebar-w) 1fr;min-height:100vh}
.sidebar{background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow:hidden}
.main{overflow-y:auto;padding:28px 32px;background:var(--navy)}
.flag-bar{height:5px;display:flex;flex-shrink:0}
.flag-bar span{flex:1}
.logo{padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;flex-shrink:0}
.logo-shield{width:36px;height:36px;background:linear-gradient(135deg,#1a1a6e,#3a3aae);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.logo-shield svg{width:20px;height:20px;fill:white}
.logo-text{font-size:12px;font-weight:700;line-height:1.3;color:var(--white)}
.logo-sub{font-size:10px;color:var(--ink3);font-weight:400}
.role-badge{margin:10px 14px;padding:6px 10px;border-radius:var(--radius-sm);font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;display:flex;align-items:center;gap:6px;flex-shrink:0}
.role-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.nav-section{padding:6px 0;flex:1;overflow-y:auto}
.nav-label{padding:6px 18px 2px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--ink3)}
.nav-item{display:flex;align-items:center;gap:9px;padding:9px 18px;cursor:pointer;font-size:13px;color:var(--ink2);border-left:2px solid transparent;transition:all .15s;user-select:none}
.nav-item:hover{background:var(--surface2);color:var(--ink)}
.nav-item.active{background:rgba(91,142,240,0.12);color:var(--blue);border-left-color:var(--blue);font-weight:500}
.nav-icon{width:15px;height:15px;flex-shrink:0;opacity:.7}
.nav-item.active .nav-icon{opacity:1}
.nav-badge{margin-left:auto;background:var(--red);color:white;border-radius:10px;padding:1px 6px;font-size:10px;font-weight:700}
.sidebar-footer{padding:12px 18px;border-top:1px solid var(--border);font-size:11px;color:var(--ink3);flex-shrink:0}
.page-header{margin-bottom:24px;display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px}
.page-title{font-size:20px;font-weight:700;letter-spacing:-.02em;color:var(--white)}
.page-sub{font-size:13px;color:var(--ink3);margin-top:3px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px}
.card+.card{margin-top:16px}
.card-title{font-size:13px;font-weight:700;margin-bottom:14px;display:flex;align-items:center;gap:8px;color:var(--white)}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px}
.stat-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--ink3);margin-bottom:6px}
.stat-value{font-size:26px;font-weight:700;letter-spacing:-.03em;line-height:1;color:var(--white)}
.stat-delta{font-size:11px;margin-top:4px;color:var(--ink3)}
.stat-delta.up{color:var(--green)}.stat-delta.down{color:var(--red)}
.badge{display:inline-flex;align-items:center;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;letter-spacing:.03em}
.b-submitted{background:var(--blue-bg);color:var(--blue)}
.b-review{background:var(--amber-bg);color:var(--amber)}
.b-verified{background:rgba(160,126,224,0.15);color:#a07ee0}
.b-assigned{background:rgba(252,220,4,0.12);color:var(--gold)}
.b-investigating{background:var(--blue-bg);color:var(--blue)}
.b-escalated{background:var(--red-bg);color:var(--red)}
.b-closed{background:var(--green-bg);color:var(--green)}
.b-rejected{background:rgba(255,255,255,0.06);color:var(--ink3)}
.b-pending{background:var(--amber-bg);color:var(--amber)}
.b-approved{background:var(--green-bg);color:var(--green)}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--ink3);padding:8px 12px;border-bottom:1px solid var(--border)}
td{padding:10px 12px;border-bottom:1px solid var(--border2);color:var(--ink2);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:var(--surface2)}
.case-id{font-family:monospace;font-size:12px;font-weight:700;background:var(--surface2);padding:2px 6px;border-radius:4px;color:var(--white)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border-radius:var(--radius-sm);font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all .15s;text-decoration:none;font-family:inherit}
.btn-primary{background:var(--gold);color:var(--navy)}
.btn-primary:hover{background:#e8ca00}
.btn-secondary{background:var(--surface2);color:var(--ink);border:1px solid var(--border)}
.btn-secondary:hover{background:var(--navy3)}
.btn-danger{background:var(--red-bg);color:var(--red);border:1px solid rgba(210,16,52,0.3)}
.btn-sm{padding:5px 10px;font-size:12px}
.btn-group{display:flex;gap:8px;flex-wrap:wrap}
.btn:disabled{opacity:.5;cursor:not-allowed}
.form-group{margin-bottom:16px}
.form-label{font-size:11px;font-weight:700;color:var(--ink2);margin-bottom:5px;display:block;text-transform:uppercase;letter-spacing:.04em}
.req{color:var(--red)}
.form-input,.form-select,.form-textarea{width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:13px;background:rgba(255,255,255,0.05);color:var(--ink);outline:none;transition:border .15s;font-family:inherit}
.form-input:focus,.form-select:focus,.form-textarea:focus{border-color:var(--blue)}
.form-select option{background:var(--navy2);color:var(--ink)}
.form-textarea{resize:vertical;min-height:80px;line-height:1.5}
.form-hint{font-size:11px;color:var(--ink3);margin-top:4px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.timeline{position:relative;padding-left:24px}
.timeline::before{content:'';position:absolute;left:7px;top:6px;bottom:6px;width:2px;background:var(--border)}
.tl-item{position:relative;margin-bottom:16px}
.tl-dot{position:absolute;left:-21px;top:3px;width:12px;height:12px;border-radius:50%;border:2px solid var(--border);background:var(--surface)}
.tl-dot.done{background:var(--gold);border-color:var(--gold)}
.tl-dot.active{background:var(--blue);border-color:var(--blue);box-shadow:0 0 0 3px var(--blue-bg)}
.tl-title{font-size:13px;font-weight:600;color:var(--white)}
.tl-meta{font-size:11px;color:var(--ink3);margin-top:1px}
.progress-wrap{background:var(--surface2);border-radius:4px;height:6px;overflow:hidden;margin-top:6px}
.progress-bar{height:100%;border-radius:4px;background:var(--gold);transition:width .3s}
.tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:20px}
.tab{padding:9px 16px;font-size:13px;cursor:pointer;color:var(--ink3);border-bottom:2px solid transparent;margin-bottom:-1px;transition:all .15s;font-weight:500}
.tab.active{color:var(--gold);border-bottom-color:var(--gold)}
.tab:hover{color:var(--ink)}
.alert{padding:12px 14px;border-radius:var(--radius-sm);font-size:12px;margin-bottom:14px;display:flex;align-items:flex-start;gap:8px}
.alert-icon{flex-shrink:0;font-size:14px;margin-top:1px}
.alert-danger{background:var(--red-bg);color:var(--red);border:1px solid rgba(210,16,52,0.25)}
.alert-warning{background:var(--amber-bg);color:var(--amber);border:1px solid rgba(224,146,26,0.25)}
.alert-success{background:var(--green-bg);color:var(--green);border:1px solid rgba(46,204,128,0.25)}
.alert-info{background:var(--blue-bg);color:var(--blue);border:1px solid rgba(91,142,240,0.25)}
.mini-bar-row{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.mini-bar-label{font-size:12px;color:var(--ink2);width:130px;flex-shrink:0}
.mini-bar-track{flex:1;background:var(--surface2);border-radius:3px;height:8px}
.mini-bar-fill{height:100%;border-radius:3px;background:var(--gold)}
.mini-bar-val{font-size:12px;color:var(--ink3);width:32px;text-align:right;flex-shrink:0}
.chat-wrap{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow-y:auto;padding:4px}
.msg{max-width:75%;padding:10px 13px;border-radius:12px;font-size:13px;line-height:1.5}
.msg-officer{background:var(--surface2);color:var(--ink);border-bottom-left-radius:4px;align-self:flex-start}
.msg-citizen{background:var(--blue);color:white;border-bottom-right-radius:4px;align-self:flex-end}
.msg-meta{font-size:10px;color:var(--ink3);margin-bottom:2px}
.upload-zone{border:2px dashed var(--border);border-radius:var(--radius);padding:24px;text-align:center;cursor:pointer;transition:all .15s}
.upload-zone:hover{border-color:var(--gold);background:rgba(252,220,4,0.04)}
.file-chip{display:inline-flex;align-items:center;gap:6px;background:var(--surface2);border:1px solid var(--border);padding:4px 10px;border-radius:20px;font-size:11px;margin:3px}
.step-strip{display:flex;align-items:center;margin-bottom:24px;overflow-x:auto;padding-bottom:2px}
.step-item{display:flex;align-items:center;flex-shrink:0}
.step-circle{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;border:2px solid var(--border);color:var(--ink3)}
.step-label{font-size:11px;margin:0 8px;white-space:nowrap;color:var(--ink3)}
.step-line{width:24px;height:2px;background:var(--border)}
.step-done .step-circle{background:var(--gold);border-color:var(--gold);color:var(--navy)}
.step-active .step-circle{background:var(--blue);border-color:var(--blue);color:white}
.step-active .step-label{color:var(--white);font-weight:600}
.step-done .step-label{color:var(--ink)}
.step-done .step-line{background:var(--gold)}
.auth-shell{min-height:100vh;background:#0e0e24;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px}
.auth-card{background:#1c1c3a;border:1px solid rgba(252,220,4,0.2);border-radius:16px;padding:36px 40px;width:420px;max-width:95vw;box-shadow:0 32px 80px rgba(0,0,0,0.5)}
.auth-error{background:rgba(210,16,52,0.15);border:1px solid rgba(210,16,52,0.3);color:#ff6b6b;border-radius:6px;padding:10px 14px;font-size:13px;margin-bottom:16px}
.loading-screen{display:flex;align-items:center;justify-content:center;min-height:100vh;font-size:13px;color:var(--ink3)}
.flag-stripe{position:fixed;top:0;left:0;right:0;display:flex;height:6px;z-index:100}
.flag-stripe span{flex:1}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}
.mt-16{margin-top:16px}.mb-16{margin-bottom:16px}.gap-8{gap:8px}.flex{display:flex}.items-center{align-items:center}.justify-between{justify-content:space-between}.flex-1{flex:1}.text-ink3{color:var(--ink3)}.text-green{color:var(--green)}.text-red{color:var(--red)}.text-amber{color:var(--amber)}.text-blue{color:var(--blue)}.text-gold{color:var(--gold)}.text-white{color:var(--white)}.font-700{font-weight:700}.border-top{border-top:1px solid var(--border2)}.pt-12{padding-top:12px}
CSSEOF

echo "CSS written."
