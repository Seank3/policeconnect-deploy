#!/bin/bash
PAGES=/var/www/policeconnect/frontend/src/pages

# ── LoginPage.jsx ─────────────────────────────────────────────────────────────
cat > $PAGES/LoginPage.jsx << 'EOF'
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../store/auth'

const DEMO = [
  ['citizen@demo.ug',  'Citizen'],
  ['officer@demo.ug',  'Officer'],
  ['admin@demo.ug',    'Station Admin'],
  ['rpc@demo.ug',      'RPC'],
  ['oversight@demo.ug','Oversight'],
]

export default function LoginPage() {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)
  const login = useAuth(s => s.login)
  const nav   = useNavigate()

  const submit = async e => {
    e.preventDefault(); setError(''); setLoading(true)
    try { await login(email, password); nav('/') }
    catch(err) { setError(err.response?.data?.detail || 'Invalid credentials.') }
    finally { setLoading(false) }
  }

  return (
    <div className="auth-shell">
      <div className="flag-stripe">
        <span style={{background:'#1a1a1a'}}/><span style={{background:'#FCDC04'}}/>
        <span style={{background:'#D21034'}}/><span style={{background:'#1a1a1a'}}/>
        <span style={{background:'#FCDC04'}}/><span style={{background:'#D21034'}}/>
      </div>
      <div style={{width:'100%',maxWidth:420}}>
        <div style={{textAlign:'center',marginBottom:28}}>
          <div style={{display:'flex',justifyContent:'center',marginBottom:14}}>
            <div style={{width:64,height:64,background:'linear-gradient(135deg,#1a1a6e,#3a3aae)',borderRadius:14,display:'flex',alignItems:'center',justifyContent:'center'}}>
              <svg viewBox="0 0 24 24" style={{width:34,height:34,fill:'white'}}><path d="M12 2L3 7v6c0 5.25 3.75 10.15 9 11.25C17.25 23.15 21 18.25 21 13V7L12 2z"/></svg>
            </div>
          </div>
          <div style={{color:'var(--gold)',fontSize:11,fontWeight:700,letterSpacing:'0.2em',textTransform:'uppercase',marginBottom:4}}>Republic of Uganda</div>
          <h1 style={{color:'#fff',fontSize:26,fontWeight:800,marginBottom:2}}>PoliceConnect UG</h1>
          <p style={{color:'rgba(255,255,255,0.45)',fontSize:13}}>Uganda Police Force · National Case Management</p>
        </div>

        <div className="auth-card">
          <div style={{height:3,background:'linear-gradient(90deg,#FCDC04,#D21034)',borderRadius:2,marginBottom:22}}/>
          {error && <div className="auth-error">{error}</div>}
          <form onSubmit={submit}>
            {[['Email address','email',email,setEmail,'officer@demo.ug'],['Password','password',password,setPassword,'••••••••']].map(([lbl,type,val,set,ph])=>(
              <div className="form-group" key={type}>
                <label className="form-label">{lbl}</label>
                <input type={type} className="form-input" value={val} placeholder={ph} required onChange={e=>set(e.target.value)}/>
              </div>
            ))}
            <button type="submit" className="btn btn-primary" disabled={loading} style={{width:'100%',justifyContent:'center',marginTop:4,padding:'11px'}}>
              {loading ? 'Signing in…' : 'Sign In →'}
            </button>
          </form>
          <p style={{textAlign:'center',fontSize:12,color:'rgba(255,255,255,0.35)',marginTop:14}}>
            No account? <Link to="/register" style={{color:'rgba(252,220,4,0.7)',textDecoration:'none'}}>Register as citizen</Link>
          </p>
        </div>

        <div style={{marginTop:14,background:'rgba(255,255,255,0.04)',borderRadius:10,padding:'12px 16px',border:'1px solid rgba(255,255,255,0.07)'}}>
          <div style={{fontSize:10,fontWeight:700,color:'rgba(252,220,4,0.6)',letterSpacing:'.1em',textTransform:'uppercase',marginBottom:8}}>Demo Accounts · Password: Demo1234!</div>
          {DEMO.map(([em,role])=>(
            <div key={em} onClick={()=>{setEmail(em);setPassword('Demo1234!')}} style={{display:'flex',justifyContent:'space-between',padding:'5px 0',cursor:'pointer',borderBottom:'1px solid rgba(255,255,255,0.05)'}}>
              <span style={{color:'rgba(255,255,255,0.7)',fontSize:12}}>{em}</span>
              <span style={{color:'rgba(252,220,4,0.5)',fontSize:11}}>{role}</span>
            </div>
          ))}
        </div>
        <p style={{textAlign:'center',fontSize:10,color:'rgba(255,255,255,0.2)',marginTop:12,lineHeight:1.6}}>All sessions are monitored and logged per UPF policy.</p>
      </div>
    </div>
  )
}
EOF

# ── RegisterPage.jsx ──────────────────────────────────────────────────────────
cat > $PAGES/RegisterPage.jsx << 'EOF'
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { authApi } from '../api'

export default function RegisterPage() {
  const [form, setForm]   = useState({email:'',password:'',first_name:'',last_name:'',phone:'',national_id:''})
  const [error, setError] = useState('')
  const [ok, setOk]       = useState(false)
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()
  const set = (k,v) => setForm(f=>({...f,[k]:v}))

  const submit = async e => {
    e.preventDefault(); setError(''); setLoading(true)
    try { await authApi.register(form); setOk(true) }
    catch(err) { setError(JSON.stringify(err.response?.data||'Registration failed.')) }
    finally { setLoading(false) }
  }

  if (ok) return (
    <div className="auth-shell">
      <div className="auth-card" style={{textAlign:'center'}}>
        <div style={{fontSize:48,marginBottom:16}}>✅</div>
        <div style={{fontSize:18,fontWeight:700,color:'var(--white)',marginBottom:8}}>Account Created!</div>
        <p style={{color:'var(--ink3)',marginBottom:20}}>You can now log in with your email and password.</p>
        <button className="btn btn-primary" style={{width:'100%',justifyContent:'center'}} onClick={()=>nav('/login')}>Go to Login</button>
      </div>
    </div>
  )

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <div style={{height:3,background:'linear-gradient(90deg,#FCDC04,#D21034)',borderRadius:2,marginBottom:20}}/>
        <h2 style={{color:'var(--white)',marginBottom:4}}>Create Citizen Account</h2>
        <p style={{color:'var(--ink3)',fontSize:12,marginBottom:20}}>Uganda Police Force · PoliceConnect UG</p>
        {error && <div className="auth-error">{error}</div>}
        <form onSubmit={submit}>
          <div className="form-row">
            <div className="form-group"><label className="form-label">First Name <span className="req">*</span></label><input className="form-input" required value={form.first_name} onChange={e=>set('first_name',e.target.value)}/></div>
            <div className="form-group"><label className="form-label">Last Name <span className="req">*</span></label><input className="form-input" required value={form.last_name} onChange={e=>set('last_name',e.target.value)}/></div>
          </div>
          <div className="form-group"><label className="form-label">Email <span className="req">*</span></label><input type="email" className="form-input" required value={form.email} onChange={e=>set('email',e.target.value)}/></div>
          <div className="form-group"><label className="form-label">Password <span className="req">*</span></label><input type="password" className="form-input" required minLength={8} value={form.password} onChange={e=>set('password',e.target.value)}/></div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Phone</label><input className="form-input" value={form.phone} placeholder="+256..." onChange={e=>set('phone',e.target.value)}/></div>
            <div className="form-group"><label className="form-label">National ID</label><input className="form-input" value={form.national_id} onChange={e=>set('national_id',e.target.value)}/></div>
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading} style={{width:'100%',justifyContent:'center'}}>{loading?'Creating account…':'Create Account'}</button>
        </form>
        <p style={{textAlign:'center',fontSize:12,color:'rgba(255,255,255,0.35)',marginTop:14}}>
          Have an account? <Link to="/login" style={{color:'rgba(252,220,4,0.7)',textDecoration:'none'}}>Sign in</Link>
        </p>
      </div>
    </div>
  )
}
EOF

# ── DashboardPage.jsx ─────────────────────────────────────────────────────────
cat > $PAGES/DashboardPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { casesApi, analyticsApi } from '../api'
import { useAuth } from '../store/auth'

const SB = { SUBMITTED:'b-submitted',UNDER_REVIEW:'b-review',VERIFIED:'b-verified',ASSIGNED:'b-assigned',INVESTIGATING:'b-investigating',ESCALATED:'b-escalated',CLOSED:'b-closed',REJECTED:'b-rejected' }
const SL = { SUBMITTED:'Submitted',UNDER_REVIEW:'Under Review',VERIFIED:'Verified',ASSIGNED:'Assigned',INVESTIGATING:'Investigating',ESCALATED:'Escalated',CLOSED:'Closed',REJECTED:'Rejected' }

export default function DashboardPage() {
  const { profile } = useAuth()
  const nav = useNavigate()
  const [cases, setCases]   = useState([])
  const [stats, setStats]   = useState(null)
  const [loading, setLoading] = useState(true)
  const role = profile?.role

  useEffect(() => {
    casesApi.list().then(r => setCases(r.data?.results||r.data||[])).catch(()=>{})
    if (['RPC','OVERSIGHT'].includes(role)) analyticsApi.overview().then(r=>setStats(r.data)).catch(()=>{})
    setLoading(false)
  }, [role])

  const open   = cases.filter(c=>c.status!=='CLOSED').length
  const closed = cases.filter(c=>c.status==='CLOSED').length
  const escal  = cases.filter(c=>c.status==='ESCALATED').length

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Welcome, {profile?.full_name?.split(' ')[0]||'User'}</div>
          <div className="page-sub">PoliceConnect UG · Uganda Police Force</div>
        </div>
        {role==='CITIZEN' && <button className="btn btn-primary" onClick={()=>nav('/cases/new')}>+ File New Case</button>}
      </div>

      <div className="grid-4" style={{marginBottom:16}}>
        <div className="stat-card"><div className="stat-label">Total Cases</div><div className="stat-value">{stats?.total??cases.length}</div><div className="stat-delta">All time</div></div>
        <div className="stat-card"><div className="stat-label">Open</div><div className="stat-value" style={{color:'var(--blue)'}}>{stats?.open??open}</div><div className="stat-delta">Active</div></div>
        <div className="stat-card"><div className="stat-label">Escalated</div><div className="stat-value" style={{color:'var(--red)'}}>{stats?.escalated??escal}</div><div className="stat-delta">Need attention</div></div>
        <div className="stat-card"><div className="stat-label">Closed</div><div className="stat-value" style={{color:'var(--green)'}}>{stats?.closed??closed}</div><div className="stat-delta">Resolved</div></div>
      </div>

      {role==='CITIZEN' && escal>0 && (
        <div className="alert alert-danger"><span className="alert-icon">🚨</span><div>One or more of your cases has been <strong>escalated</strong>. Check the Track Cases page for details.</div></div>
      )}

      <div className="card">
        <div className="card-title">{role==='CITIZEN'?'My Cases':'Recent Cases'}{loading&&<span style={{fontSize:11,color:'var(--ink3)',fontWeight:400}}> Loading…</span>}</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Case ID</th><th>Category</th><th>Location</th><th>Filed</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {cases.slice(0,15).map(c=>(
                <tr key={c.id}>
                  <td><span className="case-id">{c.reference}</span></td>
                  <td>{c.category_display}</td>
                  <td style={{fontSize:12,color:'var(--ink3)',maxWidth:160,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{c.incident_location}</td>
                  <td style={{fontSize:12,color:'var(--ink3)'}}>{new Date(c.created_at).toLocaleDateString('en-UG',{day:'numeric',month:'short',year:'numeric'})}</td>
                  <td><span className={`badge ${SB[c.status]||'b-submitted'}`}>{SL[c.status]||c.status}</span></td>
                  <td><button className="btn btn-sm btn-secondary" onClick={()=>nav(`/track?id=${c.id}`)}>View</button></td>
                </tr>
              ))}
              {!cases.length&&!loading&&(
                <tr><td colSpan={6} style={{textAlign:'center',color:'var(--ink3)',padding:'24px 0'}}>
                  No cases found.{' '}{role==='CITIZEN'&&<span style={{color:'var(--blue)',cursor:'pointer'}} onClick={()=>nav('/cases/new')}>File your first case →</span>}
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {role==='CITIZEN'&&(
        <div className="card mt-16">
          <div className="card-title">Quick Actions</div>
          <div className="btn-group">
            <button className="btn btn-primary" onClick={()=>nav('/cases/new')}>📋 File New Case</button>
            <button className="btn btn-secondary" onClick={()=>nav('/track')}>🔍 Track Cases</button>
            <button className="btn btn-secondary" onClick={()=>nav('/certificates')}>🏅 Request Certificate</button>
            <button className="btn btn-secondary" onClick={()=>nav('/tips')}>💡 Submit Anonymous Tip</button>
          </div>
        </div>
      )}
    </div>
  )
}
EOF

# ── FileCasePage.jsx ──────────────────────────────────────────────────────────
cat > $PAGES/FileCasePage.jsx << 'EOF'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { casesApi, evidenceApi } from '../api'

const STEPS  = ['Details','Evidence','Review','Done']
const CATS   = [['THEFT','Theft / Robbery'],['ASSAULT','Assault / Violence'],['LAND_DISPUTE','Land Dispute'],['FRAUD','Fraud / Cyber Crime'],['MISSING_PERSON','Missing Person'],['CORRUPTION','Corruption / Bribery'],['SEXUAL_OFFENCE','Sexual Offence'],['HOMICIDE','Homicide'],['TRAFFIC','Traffic Incident'],['LOST_FOUND','Lost & Found'],['OTHER','Other']]
const HIGH   = ['CORRUPTION','SEXUAL_OFFENCE','HOMICIDE','FRAUD','MISSING_PERSON']

export default function FileCasePage() {
  const nav = useNavigate()
  const [step, setStep]       = useState(0)
  const [saving, setSaving]   = useState(false)
  const [ref, setRef]         = useState(null)
  const [error, setError]     = useState('')
  const [files, setFiles]     = useState([])
  const [form, setForm]       = useState({category:'',title:'',description:'',incident_date:'',incident_location:'',suspect_info:'',vehicle_details:''})
  const set = (k,v) => setForm(f=>({...f,[k]:v}))
  const credScore = form.description.length>200?88:form.description.length>80?62:form.description.length>20?35:0

  const submit = async () => {
    setSaving(true); setError('')
    try {
      const { data } = await casesApi.create(form)
      setRef(data.reference)
      for (const f of files) {
        const fd = new FormData()
        fd.append('case', data.id); fd.append('file', f); fd.append('original_name', f.name)
        await evidenceApi.upload(fd).catch(()=>{})
      }
      setStep(3)
    } catch(err) { setError(err.response?.data?.detail||JSON.stringify(err.response?.data)||'Submission failed.') }
    finally { setSaving(false) }
  }

  return (
    <div>
      <div className="page-header"><div><div className="page-title">File New Case</div><div className="page-sub">Uganda Police Force · Secure & Encrypted</div></div></div>
      <div className="step-strip">
        {STEPS.map((s,i)=>(
          <div key={s} className={`step-item${i<step?' step-done':i===step?' step-active':''}`}>
            <div className="step-circle">{i<step?'✓':i+1}</div>
            <div className="step-label">{s}</div>
            {i<STEPS.length-1&&<div className="step-line"/>}
          </div>
        ))}
      </div>
      {error&&<div className="alert alert-danger"><span className="alert-icon">⚠</span><div>{error}</div></div>}

      {step===0&&(
        <div className="card">
          <div className="card-title">Case Details</div>
          <div className="form-group">
            <label className="form-label">Category <span className="req">*</span></label>
            <select className="form-select" value={form.category} onChange={e=>set('category',e.target.value)}>
              <option value="">Select…</option>
              {CATS.map(([v,l])=><option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div className="form-group"><label className="form-label">Title <span className="req">*</span></label><input className="form-input" value={form.title} onChange={e=>set('title',e.target.value)} placeholder="Brief title for your case"/></div>
          <div className="form-group">
            <label className="form-label">Full Description <span className="req">*</span></label>
            <textarea className="form-textarea" rows={5} value={form.description} onChange={e=>set('description',e.target.value)} placeholder="Describe what happened in detail…"/>
            <div className="form-hint">{form.description.length} chars</div>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Date of Incident <span className="req">*</span></label><input type="date" className="form-input" value={form.incident_date} onChange={e=>set('incident_date',e.target.value)}/></div>
            <div className="form-group"><label className="form-label">Location <span className="req">*</span></label><input className="form-input" value={form.incident_location} onChange={e=>set('incident_location',e.target.value)} placeholder="e.g. Nakasero Market, Kampala"/></div>
          </div>
          {form.category==='TRAFFIC'&&(
            <div className="form-group"><label className="form-label">Vehicle Details</label><input className="form-input" value={form.vehicle_details} onChange={e=>set('vehicle_details',e.target.value)} placeholder="Make, model, colour, plate number"/></div>
          )}
          <div className="form-group"><label className="form-label">Suspect Information</label><textarea className="form-textarea" rows={2} value={form.suspect_info} onChange={e=>set('suspect_info',e.target.value)} placeholder="Description, name if known, vehicle used…"/></div>

          <div style={{background:'var(--surface2)',borderRadius:'var(--radius)',padding:14,marginTop:8}}>
            <div style={{fontSize:12,fontWeight:700,color:'var(--gold)',marginBottom:10}}>🤖 AI Pre-Screening</div>
            <div className="grid-3">
              <div><div className="stat-label">Credibility Score</div><div style={{fontSize:22,fontWeight:700,color:credScore>70?'var(--green)':credScore>40?'var(--amber)':'var(--red)'}}>{credScore}</div><div className="progress-wrap" style={{marginTop:4}}><div className="progress-bar" style={{width:`${credScore}%`,background:credScore>70?'var(--green)':credScore>40?'var(--amber)':'var(--red)'}}/></div></div>
              <div><div className="stat-label">Duplicate Check</div><div style={{fontSize:13,fontWeight:600,color:'var(--green)',marginTop:4}}>✓ No duplicates</div></div>
              <div><div className="stat-label">Evidence Need</div><div style={{fontSize:13,fontWeight:600,color:HIGH.includes(form.category)?'var(--red)':'var(--amber)',marginTop:4}}>{HIGH.includes(form.category)?'⚠ Required':'Recommended'}</div></div>
            </div>
          </div>
          <div style={{display:'flex',justifyContent:'flex-end',marginTop:18}}>
            <button className="btn btn-primary" disabled={!form.category||!form.title||!form.description||!form.incident_date||!form.incident_location} onClick={()=>setStep(1)}>Next: Evidence →</button>
          </div>
        </div>
      )}

      {step===1&&(
        <div className="card">
          <div className="card-title">Upload Evidence</div>
          <div className="alert alert-info"><span className="alert-icon">🔒</span><div>All files are SHA-256 hashed on upload. Hashes are stored immutably in the audit log.</div></div>
          <label className="upload-zone" style={{display:'block'}}>
            <div style={{fontSize:28,marginBottom:8}}>📎</div>
            <div style={{fontWeight:600,color:'var(--white)'}}>Click to add files</div>
            <div style={{fontSize:12,color:'var(--ink3)',marginTop:4}}>Photos · Videos · Documents · Audio · Max 50MB each</div>
            <input type="file" multiple style={{display:'none'}} onChange={e=>setFiles(f=>[...f,...Array.from(e.target.files)])}/>
          </label>
          {files.length>0&&<div style={{marginTop:10}}>{files.map((f,i)=><span key={i} className="file-chip">📄 {f.name}<span style={{cursor:'pointer',color:'var(--ink3)',marginLeft:4}} onClick={()=>setFiles(fs=>fs.filter((_,j)=>j!==i))}>×</span></span>)}</div>}
          <div style={{display:'flex',justifyContent:'space-between',marginTop:18}}>
            <button className="btn btn-secondary" onClick={()=>setStep(0)}>← Back</button>
            <button className="btn btn-primary" onClick={()=>setStep(2)}>Next: Review →</button>
          </div>
        </div>
      )}

      {step===2&&(
        <div className="card">
          <div className="card-title">Review & Submit</div>
          <div style={{display:'grid',gap:10,marginBottom:18}}>
            {[['Category',CATS.find(c=>c[0]===form.category)?.[1]||'—'],['Title',form.title],['Date',form.incident_date],['Location',form.incident_location],['Suspect Info',form.suspect_info||'—'],['Evidence',files.length?`${files.length} file(s) attached`:'None']].map(([k,v])=>(
              <div key={k} style={{display:'flex',gap:12}}><div style={{width:120,fontSize:11,fontWeight:700,color:'var(--ink3)',textTransform:'uppercase'}}>{k}</div><div style={{fontSize:13,color:'var(--ink)'}}>{v}</div></div>
            ))}
          </div>
          <div className="alert alert-warning"><span className="alert-icon">⚠</span><div>Once submitted, a case <strong>cannot be deleted</strong>. Submitting false information is a criminal offence.</div></div>
          <div style={{display:'flex',justifyContent:'space-between',marginTop:8}}>
            <button className="btn btn-secondary" onClick={()=>setStep(1)}>← Back</button>
            <button className="btn btn-primary" onClick={submit} disabled={saving}>{saving?'Submitting…':'✓ Submit Case'}</button>
          </div>
        </div>
      )}

      {step===3&&(
        <div className="card" style={{textAlign:'center',padding:'48px 40px'}}>
          <div style={{fontSize:48,marginBottom:16}}>✅</div>
          <div style={{fontSize:20,fontWeight:700,color:'var(--white)',marginBottom:8}}>Case Submitted Successfully</div>
          {ref&&<div style={{marginBottom:12}}>Reference: <span className="case-id" style={{fontSize:14}}>{ref}</span></div>}
          <p style={{color:'var(--ink3)',maxWidth:400,margin:'0 auto',lineHeight:1.7,fontSize:13}}>Your case will be reviewed within 24 hours. You will be notified when an officer is assigned. Save your reference number.</p>
          <div className="btn-group" style={{justifyContent:'center',marginTop:24}}>
            <button className="btn btn-primary" onClick={()=>nav('/track')}>Track My Case</button>
            <button className="btn btn-secondary" onClick={()=>{setStep(0);setForm({category:'',title:'',description:'',incident_date:'',incident_location:'',suspect_info:'',vehicle_details:''});setFiles([])}}>File Another</button>
          </div>
        </div>
      )}
    </div>
  )
}
EOF

# ── TrackPage.jsx ─────────────────────────────────────────────────────────────
cat > $PAGES/TrackPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { casesApi, evidenceApi } from '../api'

const STEPS = [{key:'SUBMITTED',label:'Submitted'},{key:'UNDER_REVIEW',label:'Under Review'},{key:'VERIFIED',label:'Verified'},{key:'ASSIGNED',label:'Assigned to Officer'},{key:'INVESTIGATING',label:'Investigating'},{key:'CLOSED',label:'Closed'}]
const SB = {SUBMITTED:'b-submitted',UNDER_REVIEW:'b-review',VERIFIED:'b-verified',ASSIGNED:'b-assigned',INVESTIGATING:'b-investigating',ESCALATED:'b-escalated',CLOSED:'b-closed'}

export default function TrackPage() {
  const nav = useNavigate()
  const [params] = useSearchParams()
  const [cases, setCases]     = useState([])
  const [active, setActive]   = useState(null)
  const [evidence, setEvidence] = useState([])
  const [loading, setLoading]   = useState(true)

  useEffect(()=>{
    casesApi.list().then(r=>{
      const list = r.data?.results||r.data||[]
      setCases(list)
      const target = params.get('id') ? list.find(c=>c.id===params.get('id')) : list[0]
      if(target){ setActive(target); evidenceApi.list(target.id).then(r2=>setEvidence(r2.data?.results||r2.data||[])).catch(()=>{}) }
    }).catch(()=>{}).finally(()=>setLoading(false))
  },[])

  if (loading) return <div className="loading-screen">Loading cases…</div>
  if (!active) return <div className="card"><p style={{color:'var(--ink3)',textAlign:'center',padding:'24px 0'}}>No cases found. <span style={{color:'var(--blue)',cursor:'pointer'}} onClick={()=>nav('/cases/new')}>File a case →</span></p></div>

  const stepIdx  = STEPS.findIndex(s=>s.key===active.status)
  const progress = Math.round(((Math.max(stepIdx,0)+1)/STEPS.length)*100)
  const FILE_ICONS = {IMAGE:'📷',VIDEO:'🎥',AUDIO:'🎵',DOCUMENT:'📄',OTHER:'📎'}

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">{active.reference}</div>
          <div className="page-sub">{active.category_display} · {active.station_name||'Pending assignment'}</div>
        </div>
        {cases.length>1&&(
          <select className="form-select" style={{width:'auto'}} onChange={e=>{const c=cases.find(x=>x.id===e.target.value);if(c){setActive(c);evidenceApi.list(c.id).then(r=>setEvidence(r.data?.results||r.data||[])).catch(()=>{})}}}>
            {cases.map(c=><option key={c.id} value={c.id}>{c.reference} — {c.status}</option>)}
          </select>
        )}
      </div>

      {active.status==='ESCALATED'&&<div className="alert alert-danger"><span className="alert-icon">🚨</span><div>This case has been <strong>escalated</strong>. Senior officers have been notified.</div></div>}

      <div className="grid-2">
        <div className="card">
          <div className="card-title">Investigation Progress</div>
          <div style={{marginBottom:14}}>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:4}}><span style={{color:'var(--ink2)'}}>Progress</span><span style={{color:'var(--gold)',fontWeight:600}}>{progress}%</span></div>
            <div className="progress-wrap" style={{height:10}}><div className="progress-bar" style={{width:`${progress}%`}}/></div>
          </div>
          <div className="timeline">
            {STEPS.map((s,i)=>{
              const hist = active.status_history?.find(h=>h.status===s.key)
              const done = i<stepIdx; const act = i===stepIdx
              return (
                <div className="tl-item" key={s.key}>
                  <div className={`tl-dot${done?' done':act?' active':''}`}/>
                  <div className="tl-title">{s.label}{act?' — In Progress':''}</div>
                  {hist?<div className="tl-meta">{new Date(hist.changed_at).toLocaleDateString('en-UG',{day:'numeric',month:'short',year:'numeric'})} · {hist.changed_by_name} {hist.note&&`· ${hist.note}`}</div>:<div className="tl-meta text-ink3">Pending</div>}
                </div>
              )
            })}
          </div>
          {active.assigned_officer_name&&(
            <div className="border-top pt-12" style={{marginTop:8}}>
              <div style={{fontSize:12,fontWeight:700,color:'var(--ink2)',marginBottom:8}}>Assigned Officer</div>
              <div style={{display:'flex',gap:10,alignItems:'center'}}>
                <div style={{width:36,height:36,borderRadius:'50%',background:'var(--blue-bg)',color:'var(--blue)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700}}>{active.assigned_officer_name[0]}</div>
                <div>
                  <div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>{active.assigned_officer_name}</div>
                  <div style={{fontSize:11,color:'var(--ink3)'}}>{active.station_name}</div>
                </div>
                <button className="btn btn-sm btn-secondary" style={{marginLeft:'auto'}} onClick={()=>nav('/messages')}>Message</button>
              </div>
            </div>
          )}
        </div>
        <div className="card">
          <div className="card-title">Evidence Files ({evidence.length})</div>
          {evidence.length===0&&<div style={{color:'var(--ink3)',fontSize:13,marginBottom:12}}>No evidence uploaded yet.</div>}
          {evidence.map(ev=>(
            <div key={ev.id} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 0',borderBottom:'1px solid var(--border2)'}}>
              <span style={{fontSize:18}}>{FILE_ICONS[ev.file_type]||'📎'}</span>
              <div style={{flex:1}}><div style={{fontSize:13,color:'var(--white)'}}>{ev.original_name}</div><div style={{fontSize:11,color:'var(--ink3)'}}>{ev.sha256_hash?`SHA: ${ev.sha256_hash.slice(0,16)}…`:'Pending hash'}</div></div>
              {ev.sha256_hash&&<span style={{color:'var(--green)',fontSize:11}}>✓</span>}
            </div>
          ))}
          <label className="upload-zone" style={{display:'block',padding:14,marginTop:12}}>
            <div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>Upload More Evidence</div>
            <div style={{fontSize:11,color:'var(--ink3)',marginTop:4}}>Add photos, videos or documents</div>
            <input type="file" multiple style={{display:'none'}} onChange={async e=>{
              for(const file of Array.from(e.target.files)){
                const fd=new FormData(); fd.append('case',active.id); fd.append('file',file); fd.append('original_name',file.name)
                await evidenceApi.upload(fd).catch(()=>{})
              }
              evidenceApi.list(active.id).then(r=>setEvidence(r.data?.results||r.data||[])).catch(()=>{})
            }}/>
          </label>
          <div className="border-top pt-12 mt-16">
            <div style={{fontSize:12,fontWeight:700,color:'var(--ink2)',marginBottom:6}}>🔒 Immutable Audit</div>
            <div style={{fontSize:12,color:'var(--ink3)',lineHeight:1.6}}>{active.status_history?.length||0} audit entries. No data can be deleted or modified.</div>
          </div>
        </div>
      </div>
    </div>
  )
}
EOF

# ── MessagesPage.jsx ──────────────────────────────────────────────────────────
cat > $PAGES/MessagesPage.jsx << 'EOF'
import { useEffect, useRef, useState } from 'react'
import { casesApi, messagingApi } from '../api'
import { useAuth } from '../store/auth'

export default function MessagesPage() {
  const { profile } = useAuth()
  const [cases, setCases]     = useState([])
  const [active, setActive]   = useState(null)
  const [messages, setMessages] = useState([])
  const [input, setInput]     = useState('')
  const [sending, setSending] = useState(false)
  const bottomRef = useRef()

  useEffect(()=>{ casesApi.list().then(r=>{ const l=r.data?.results||r.data||[]; setCases(l); if(l[0]) loadMsgs(l[0]) }).catch(()=>{}) },[])
  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:'smooth'}) },[messages])

  const loadMsgs = c => { setActive(c); messagingApi.list(c.id).then(r=>setMessages(r.data?.results||r.data||[])).catch(()=>{}) }
  const send = async () => {
    if (!input.trim()||!active) return
    setSending(true)
    setMessages(m=>[...m,{id:Date.now(),sender_name:profile?.full_name||'You',sender_role:profile?.role,content:input,created_at:new Date().toISOString()}])
    const txt=input; setInput('')
    try { await messagingApi.send({case:active.id,content:txt}) } catch {}
    setSending(false)
  }

  return (
    <div>
      <div className="page-header"><div><div className="page-title">Secure Messages</div><div className="page-sub">Encrypted case communications</div></div></div>
      <div className="grid-2" style={{alignItems:'flex-start'}}>
        <div className="card">
          <div className="card-title">Case Threads</div>
          {cases.map(c=>(
            <div key={c.id} onClick={()=>loadMsgs(c)} style={{padding:'10px 12px',borderRadius:'var(--radius-sm)',cursor:'pointer',background:active?.id===c.id?'var(--surface2)':'transparent',marginBottom:4,border:'1px solid '+(active?.id===c.id?'var(--border)':'transparent')}}>
              <div style={{fontSize:13,fontWeight:600,color:'var(--white)'}}>{c.reference}</div>
              <div style={{fontSize:11,color:'var(--ink3)'}}>{c.category_display} · {c.assigned_officer_name||'Unassigned'}</div>
            </div>
          ))}
          {!cases.length&&<div style={{color:'var(--ink3)',fontSize:13}}>No active cases.</div>}
        </div>
        <div className="card">
          {active?(
            <>
              <div style={{display:'flex',alignItems:'center',gap:10,paddingBottom:12,borderBottom:'1px solid var(--border2)',marginBottom:12}}>
                <div style={{width:36,height:36,borderRadius:'50%',background:'var(--blue-bg)',color:'var(--blue)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700}}>{(active.assigned_officer_name||'?')[0]}</div>
                <div>
                  <div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>{active.assigned_officer_name||'Awaiting assignment'}</div>
                  <div style={{fontSize:11,color:'var(--ink3)'}}>Case {active.reference}</div>
                </div>
                <div style={{marginLeft:'auto',fontSize:11,color:'var(--ink3)'}}>🔒 Encrypted</div>
              </div>
              <div className="chat-wrap">
                {messages.map(msg=>{
                  const mine = msg.sender_role==='CITIZEN'||(msg.sender_name===profile?.full_name)
                  return (
                    <div key={msg.id} style={{display:'flex',flexDirection:'column',alignItems:mine?'flex-end':'flex-start'}}>
                      <div className="msg-meta" style={{paddingLeft:mine?0:4,paddingRight:mine?4:0}}>{msg.sender_name} · {new Date(msg.created_at).toLocaleTimeString('en-UG',{hour:'2-digit',minute:'2-digit'})}</div>
                      <div className={`msg ${mine?'msg-citizen':'msg-officer'}`}>{msg.content}</div>
                    </div>
                  )
                })}
                {!messages.length&&<div style={{textAlign:'center',color:'var(--ink3)',fontSize:13,padding:'20px 0'}}>No messages yet. Start the conversation.</div>}
                <div ref={bottomRef}/>
              </div>
              <div style={{display:'flex',gap:8,marginTop:12,paddingTop:12,borderTop:'1px solid var(--border2)'}}>
                <input className="form-input" style={{flex:1}} placeholder="Type a message…" value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&send()} disabled={sending}/>
                <button className="btn btn-primary" onClick={send} disabled={sending||!input.trim()}>Send</button>
              </div>
            </>
          ):<div style={{textAlign:'center',color:'var(--ink3)',padding:'40px 0',fontSize:13}}>Select a case to view messages</div>}
        </div>
      </div>
    </div>
  )
}
EOF

# ── OfficerQueuePage.jsx ──────────────────────────────────────────────────────
cat > $PAGES/OfficerQueuePage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { casesApi } from '../api'
import { useAuth } from '../store/auth'

const SB={SUBMITTED:'b-submitted',UNDER_REVIEW:'b-review',ASSIGNED:'b-assigned',INVESTIGATING:'b-investigating',ESCALATED:'b-escalated',CLOSED:'b-closed'}
const SL={SUBMITTED:'Submitted',UNDER_REVIEW:'Under Review',ASSIGNED:'Assigned',INVESTIGATING:'Investigating',ESCALATED:'Escalated',CLOSED:'Closed'}

export default function OfficerQueuePage() {
  const { profile } = useAuth()
  const nav = useNavigate()
  const [queue, setQueue]   = useState([])
  const [sel, setSel]       = useState(null)
  const [newStatus, setNewStatus] = useState('')
  const [note, setNote]     = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(()=>{ casesApi.myQueue().then(r=>setQueue(r.data?.results||r.data||[])).catch(()=>{}) },[])

  const updateStatus = async id => {
    if (!newStatus) return
    setSaving(true)
    try { await casesApi.updateStatus(id,{status:newStatus,note}); setQueue(q=>q.map(c=>c.id===id?{...c,status:newStatus}:c)); setSel(null);setNote('');setNewStatus('') }
    catch(e){ alert(e.response?.data?.detail||'Update failed') }
    finally { setSaving(false) }
  }

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Case Queue — {profile?.full_name}</div><div className="page-sub">{profile?.station_name} · Badge {profile?.badge_number}</div></div>
        <div style={{textAlign:'right',fontSize:12,color:'var(--ink3)'}}><div>Active: <strong style={{color:'var(--white)'}}>{queue.length}</strong></div></div>
      </div>
      <div className="grid-4" style={{marginBottom:16}}>
        <div className="stat-card"><div className="stat-label">Assigned</div><div className="stat-value">{queue.length}</div></div>
        <div className="stat-card"><div className="stat-label">Investigating</div><div className="stat-value" style={{color:'var(--blue)'}}>{queue.filter(c=>c.status==='INVESTIGATING').length}</div></div>
        <div className="stat-card"><div className="stat-label">Escalated</div><div className="stat-value" style={{color:'var(--red)'}}>{queue.filter(c=>c.status==='ESCALATED').length}</div></div>
        <div className="stat-card"><div className="stat-label">Overdue (30d+)</div><div className="stat-value" style={{color:'var(--amber)'}}>{queue.filter(c=>c.days_open>30).length}</div></div>
      </div>
      <div className="card">
        <div className="card-title">My Active Cases</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Case ID</th><th>Category</th><th>Citizen</th><th>Days Open</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {queue.map(c=>(
                <>
                  <tr key={c.id}>
                    <td><span className="case-id">{c.reference}</span></td>
                    <td>{c.category_display}</td>
                    <td style={{fontWeight:500}}>{c.citizen_name}</td>
                    <td style={{fontWeight:600,color:c.days_open>60?'var(--red)':c.days_open>14?'var(--amber)':'var(--green)'}}>{c.days_open}d</td>
                    <td><span className={`badge ${SB[c.status]||'b-submitted'}`}>{SL[c.status]||c.status}</span></td>
                    <td><button className="btn btn-sm btn-secondary" onClick={()=>setSel(sel===c.id?null:c.id)}>Update</button></td>
                  </tr>
                  {sel===c.id&&(
                    <tr key={c.id+'_edit'}><td colSpan={6} style={{padding:'0 12px 12px'}}>
                      <div style={{background:'var(--surface2)',borderRadius:'var(--radius)',padding:14}}>
                        <div className="form-row">
                          <div className="form-group">
                            <label className="form-label">New Status</label>
                            <select className="form-select" value={newStatus} onChange={e=>setNewStatus(e.target.value)}>
                              <option value="">Select…</option>
                              <option value="INVESTIGATING">Investigating</option>
                              <option value="ESCALATED">Escalate</option>
                              <option value="CLOSED">Close Case</option>
                            </select>
                          </div>
                          <div className="form-group">
                            <label className="form-label">Note</label>
                            <input className="form-input" value={note} onChange={e=>setNote(e.target.value)} placeholder="Update note for audit log"/>
                          </div>
                        </div>
                        <div className="btn-group">
                          <button className="btn btn-primary btn-sm" onClick={()=>updateStatus(c.id)} disabled={!newStatus||saving}>{saving?'Saving…':'Save'}</button>
                          <button className="btn btn-secondary btn-sm" onClick={()=>setSel(null)}>Cancel</button>
                          <button className="btn btn-secondary btn-sm" style={{marginLeft:'auto'}} onClick={()=>nav('/messages')}>Message Citizen</button>
                        </div>
                      </div>
                    </td></tr>
                  )}
                </>
              ))}
              {!queue.length&&<tr><td colSpan={6} style={{textAlign:'center',color:'var(--ink3)',padding:'24px 0'}}>No cases assigned to you yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
EOF

# ── AdminPage.jsx ─────────────────────────────────────────────────────────────
cat > $PAGES/AdminPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { casesApi, stationsApi } from '../api'
import { useAuth } from '../store/auth'

export default function AdminPage() {
  const { profile } = useAuth()
  const [unassigned, setUnassigned] = useState([])
  const [assigning, setAssigning]   = useState(null)

  useEffect(()=>{ casesApi.unassigned().then(r=>setUnassigned(r.data?.results||r.data||[])).catch(()=>{}) },[])

  const OFFICERS = [{id:'off1',name:'Okello James',load:14,badge:'KCP-4412'},{id:'off2',name:'Nalwoga Rose',load:8,badge:'KCP-4413'},{id:'off3',name:'Mugisha Paul',load:5,badge:'KCP-4414'}]

  return (
    <div>
      <div className="page-header"><div><div className="page-title">Station Admin — {profile?.station_name||'Station'}</div><div className="page-sub">Case assignment · Officer workloads · Compliance</div></div></div>
      <div className="grid-4" style={{marginBottom:16}}>
        <div className="stat-card"><div className="stat-label">Unassigned</div><div className="stat-value" style={{color:'var(--red)'}}>{unassigned.length}</div></div>
        <div className="stat-card"><div className="stat-label">Officers On Duty</div><div className="stat-value" style={{color:'var(--green)'}}>18</div></div>
        <div className="stat-card"><div className="stat-label">Station Cases</div><div className="stat-value">186</div></div>
        <div className="stat-card"><div className="stat-label">Avg Resolution</div><div className="stat-value">5.8d</div></div>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">Officer Workloads</div>
          {OFFICERS.map(o=>(
            <div className="mini-bar-row" key={o.id}>
              <div className="mini-bar-label">{o.name}</div>
              <div className="mini-bar-track"><div className="mini-bar-fill" style={{width:`${(o.load/20)*100}%`,background:o.load>15?'var(--red)':o.load>10?'var(--amber)':'var(--green)'}}/></div>
              <div className="mini-bar-val">{o.load}</div>
            </div>
          ))}
          <div className="border-top pt-12" style={{marginTop:8}}>
            <div style={{fontSize:12,color:'var(--ink3)'}}>🤖 AI recommends assigning new cases to <strong style={{color:'var(--white)'}}>Mugisha Paul</strong> (lowest load)</div>
          </div>
        </div>
        <div className="card">
          <div className="card-title">Unassigned Cases ({unassigned.length})</div>
          {unassigned.length===0&&<div style={{textAlign:'center',color:'var(--green)',padding:'20px 0',fontSize:13}}>✓ All cases assigned</div>}
          <table>
            <thead><tr><th>Case ID</th><th>Category</th><th>Priority</th><th></th></tr></thead>
            <tbody>
              {unassigned.map(c=>(
                <tr key={c.id}>
                  <td><span className="case-id">{c.reference}</span></td>
                  <td>{c.category_display}</td>
                  <td><span className={`badge ${c.priority==='URGENT'?'b-escalated':'b-review'}`}>{c.priority}</span></td>
                  <td>
                    {assigning===c.id?(
                      <select className="form-select" style={{padding:'4px 8px',fontSize:12}} onChange={e=>{if(e.target.value){casesApi.assignOfficer(c.id,{officer_id:e.target.value}).then(()=>{setUnassigned(u=>u.filter(x=>x.id!==c.id));setAssigning(null)}).catch(()=>{})}}}>
                        <option value="">Pick officer…</option>
                        {OFFICERS.map(o=><option key={o.id} value={o.id}>{o.name} ({o.load})</option>)}
                      </select>
                    ):<button className="btn btn-sm btn-secondary" onClick={()=>setAssigning(c.id)}>Assign</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="card mt-16">
        <div className="card-title">Compliance Metrics</div>
        <div className="grid-3">
          {[['Cases Updated This Week','94%','var(--green)'],['Evidence Logged Rate','78%','var(--blue)'],['Escalation Compliance','61%','var(--amber)']].map(([l,v,c])=>(
            <div key={l} style={{textAlign:'center',padding:14,background:'var(--surface2)',borderRadius:'var(--radius)'}}>
              <div style={{fontSize:28,fontWeight:700,color:c}}>{v}</div>
              <div style={{fontSize:12,color:'var(--ink3)',marginTop:4}}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
EOF

# ── OversightPage.jsx ─────────────────────────────────────────────────────────
cat > $PAGES/OversightPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { analyticsApi } from '../api'

export default function OversightPage() {
  const [stats, setStats] = useState(null)
  useEffect(()=>{ analyticsApi.overview().then(r=>setStats(r.data)).catch(()=>{}) },[])
  const FLAGS = [
    {icon:'🚨',title:'Masindi Station — 34 cases rejected without review in 7 days',desc:'Anomalous rejection rate detected. May indicate systemic case suppression.',danger:true},
    {icon:'⚠',title:'Case idle for 60+ days — Jinja Region',desc:'No status update for 63 days. Officer Ssekandi. Pattern matches delay-for-corruption signature.',danger:true},
    {icon:'📊',title:'Kampala — Officer with 0% escalation rate over 89 cases',desc:'All cases closed as resolved. Outlier vs district avg of 12% escalation.',danger:false},
  ]
  return (
    <div>
      <div className="page-header"><div><div className="page-title">National Oversight</div><div className="page-sub">Anti-corruption monitoring · All 107 stations</div></div></div>
      <div className="grid-4" style={{marginBottom:16}}>
        <div className="stat-card"><div className="stat-label">National Cases</div><div className="stat-value">{stats?.total||'14,882'}</div></div>
        <div className="stat-card"><div className="stat-label">Open</div><div className="stat-value" style={{color:'var(--blue)'}}>{stats?.open||'9,431'}</div></div>
        <div className="stat-card"><div className="stat-label">Escalated</div><div className="stat-value" style={{color:'var(--red)'}}>{stats?.escalated||431}</div></div>
        <div className="stat-card"><div className="stat-label">Corruption Flags</div><div className="stat-value" style={{color:'var(--red)'}}>18</div><div className="stat-delta down">Active investigations</div></div>
      </div>
      <div className="card">
        <div className="card-title">⚠ Active Anti-Corruption Flags</div>
        {FLAGS.map((f,i)=>(
          <div key={i} style={{display:'flex',gap:12,padding:'12px 0',borderBottom:'1px solid var(--border2)'}}>
            <div style={{width:36,height:36,borderRadius:8,background:f.danger?'var(--red-bg)':'var(--amber-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0}}>{f.icon}</div>
            <div style={{flex:1}}>
              <div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>{f.title}</div>
              <div style={{fontSize:12,color:'var(--ink3)',marginTop:2}}>{f.desc}</div>
            </div>
            <button className={`btn btn-sm ${f.danger?'btn-danger':'btn-secondary'}`}>Investigate</button>
          </div>
        ))}
      </div>
      <div className="card mt-16">
        <div className="card-title">Regional Risk Index</div>
        {[['Kampala Central',72,'var(--red)'],['Masindi',68,'var(--red)'],['Jinja Region',48,'var(--amber)'],['Gulu Region',35,'var(--amber)'],['Mbarara',22,'var(--green)'],['Western Region',18,'var(--green)']].map(([r,v,c])=>(
          <div className="mini-bar-row" key={r}><div className="mini-bar-label">{r}</div><div className="mini-bar-track"><div className="mini-bar-fill" style={{width:`${v}%`,background:c}}/></div><div className="mini-bar-val" style={{color:c}}>{v}</div></div>
        ))}
      </div>
    </div>
  )
}
EOF

# ── AuditPage.jsx ─────────────────────────────────────────────────────────────
cat > $PAGES/AuditPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { auditApi } from '../api'

export default function AuditPage() {
  const [logs, setLogs] = useState([])
  useEffect(()=>{ auditApi.list().then(r=>setLogs(r.data?.results||r.data||[])).catch(()=>{}) },[])
  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Audit Logs</div><div className="page-sub">Immutable · Tamper-proof · All entries permanent</div></div>
        <button className="btn btn-secondary">Export CSV</button>
      </div>
      <div className="card">
        <div className="card-title">Recent Activity</div>
        {logs.length===0&&<div style={{color:'var(--ink3)',fontSize:13,textAlign:'center',padding:'20px 0'}}>No audit entries yet.</div>}
        {logs.map(log=>(
          <div key={log.id} style={{display:'flex',gap:10,padding:'10px 0',borderBottom:'1px solid var(--border2)',alignItems:'flex-start'}}>
            <div style={{width:28,height:28,borderRadius:'50%',background:'var(--blue-bg)',color:'var(--blue)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0,marginTop:1}}>{(log.actor_name||'?')[0]}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:12,color:'var(--ink)'}}><strong>{log.actor_name||'System'}</strong> · {log.action} {log.target_id&&<span className="case-id" style={{fontSize:11}}>{log.target_id}</span>}</div>
              <div style={{fontSize:11,color:'var(--ink3)',marginTop:2,display:'flex',gap:8}}>
                <span>{new Date(log.created_at).toLocaleString('en-UG')}</span>
                {log.ip_address&&<span style={{fontFamily:'monospace',fontSize:10,background:'var(--surface2)',padding:'1px 4px',borderRadius:3}}>{log.ip_address}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
EOF

# ── AnalyticsPage.jsx ─────────────────────────────────────────────────────────
cat > $PAGES/AnalyticsPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { analyticsApi } from '../api'

export default function AnalyticsPage() {
  const [data, setData] = useState(null)
  useEffect(()=>{ analyticsApi.overview().then(r=>setData(r.data)).catch(()=>{}) },[])
  const cats = data?.by_category||[]
  const maxCat = Math.max(...cats.map(c=>c.count),1)
  return (
    <div>
      <div className="page-header"><div><div className="page-title">National Analytics</div><div className="page-sub">Real-time crime intelligence · All stations</div></div></div>
      <div className="grid-4" style={{marginBottom:16}}>
        <div className="stat-card"><div className="stat-label">Total Cases</div><div className="stat-value">{data?.total||0}</div></div>
        <div className="stat-card"><div className="stat-label">Open</div><div className="stat-value" style={{color:'var(--blue)'}}>{data?.open||0}</div></div>
        <div className="stat-card"><div className="stat-label">Closed</div><div className="stat-value" style={{color:'var(--green)'}}>{data?.closed||0}</div></div>
        <div className="stat-card"><div className="stat-label">Escalated</div><div className="stat-value" style={{color:'var(--red)'}}>{data?.escalated||0}</div></div>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">Cases by Category</div>
          {cats.length===0&&<div style={{color:'var(--ink3)',fontSize:13}}>No data yet.</div>}
          {cats.map(c=>(
            <div className="mini-bar-row" key={c.category}>
              <div className="mini-bar-label" style={{width:150}}>{c.category}</div>
              <div className="mini-bar-track"><div className="mini-bar-fill" style={{width:`${(c.count/maxCat)*100}%`}}/></div>
              <div className="mini-bar-val">{c.count}</div>
            </div>
          ))}
        </div>
        <div className="card">
          <div className="card-title">🤖 AI Predictive Alerts</div>
          <div style={{display:'flex',gap:10,padding:'10px 0',borderBottom:'1px solid var(--border2)'}}>
            <div style={{width:32,height:32,borderRadius:8,background:'var(--amber-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,flexShrink:0}}>🤖</div>
            <div><div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>Predicted 15% case surge — Kampala</div><div style={{fontSize:12,color:'var(--ink3)',marginTop:2}}>Based on seasonal patterns + upcoming public events. Confidence: 78%</div></div>
          </div>
          <div style={{display:'flex',gap:10,padding:'10px 0'}}>
            <div style={{width:32,height:32,borderRadius:8,background:'var(--blue-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,flexShrink:0}}>🗺</div>
            <div><div style={{fontWeight:600,fontSize:13,color:'var(--white)'}}>Crime hotspot emerging — Ntinda</div><div style={{fontSize:12,color:'var(--ink3)',marginTop:2}}>Theft reports up 40% this week near Ntinda Market. Patrol deployment recommended.</div></div>
          </div>
        </div>
      </div>
    </div>
  )
}
EOF

# ── CertificatesPage.jsx ──────────────────────────────────────────────────────
cat > $PAGES/CertificatesPage.jsx << 'EOF'
import { useEffect, useState } from 'react'
import { certificatesApi } from '../api'
import { useAuth } from '../store/auth'

export default function CertificatesPage({ admin }) {
  const { profile } = useAuth()
  const [certs, setCerts] = useState([])
  const [form, setForm]   = useState({purpose:''})
  const [submitting, setSub] = useState(false)
  const [ok, setOk]       = useState(false)

  useEffect(()=>{ certificatesApi.list().then(r=>setCerts(r.data?.results||r.data||[])).catch(()=>{}) },[])

  const submit = async e => {
    e.preventDefault(); setSub(true)
    try { await certificatesApi.create(form); setOk(true); certificatesApi.list().then(r=>setCerts(r.data?.results||r.data||[])) }
    catch {} finally { setSub(false) }
  }
  const review = async (id, status) => {
    try { await certificatesApi.review(id,{status}); setCerts(c=>c.map(x=>x.id===id?{...x,status}:x)) } catch {}
  }
  const SB={PENDING:'b-pending',APPROVED:'b-approved',REJECTED:'b-rejected'}

  return (
    <div>
      <div className="page-header"><div><div className="page-title">Good Conduct Certificates</div><div className="page-sub">{admin?'Review applications':'Apply for a police clearance certificate'}</div></div></div>
      {!admin&&(
        <div className="card" style={{marginBottom:16}}>
          <div className="card-title">Apply for Certificate</div>
          {ok&&<div className="alert alert-success"><span className="alert-icon">✅</span><div>Application submitted! You will be notified when reviewed.</div></div>}
          <form onSubmit={submit}>
            <div className="form-group"><label className="form-label">Purpose <span className="req">*</span></label><input className="form-input" required value={form.purpose} onChange={e=>setForm({purpose:e.target.value})} placeholder="e.g. Employment, Travel visa, University admission"/></div>
            <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting?'Submitting…':'Submit Application'}</button>
          </form>
        </div>
      )}
      <div className="card">
        <div className="card-title">{admin?'All Applications':'My Applications'}</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>ID</th><th>Applicant</th><th>Purpose</th><th>Submitted</th><th>Status</th>{admin&&<th>Action</th>}</tr></thead>
            <tbody>
              {certs.map(c=>(
                <tr key={c.id}>
                  <td><span className="case-id">{c.id.slice(0,8)}</span></td>
                  <td style={{fontWeight:500}}>{c.applicant_name}</td>
                  <td>{c.purpose}</td>
                  <td style={{fontSize:12,color:'var(--ink3)'}}>{new Date(c.created_at).toLocaleDateString('en-UG',{day:'numeric',month:'short',year:'numeric'})}</td>
                  <td><span className={`badge ${SB[c.status]}`}>{c.status}</span></td>
                  {admin&&<td>
                    {c.status==='PENDING'&&<div className="btn-group">
                      <button className="btn btn-sm btn-primary" onClick={()=>review(c.id,'APPROVED')}>Approve</button>
                      <button className="btn btn-sm btn-danger" onClick={()=>review(c.id,'REJECTED')}>Reject</button>
                    </div>}
                  </td>}
                </tr>
              ))}
              {!certs.length&&<tr><td colSpan={6} style={{textAlign:'center',color:'var(--ink3)',padding:'20px 0'}}>No applications found.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
EOF

# ── TipsPage.jsx ──────────────────────────────────────────────────────────────
cat > $PAGES/TipsPage.jsx << 'EOF'
import { useState } from 'react'
import { tipsApi } from '../api'

export default function TipsPage() {
  const [form, setForm] = useState({content:'',category:'',location:''})
  const [ok, setOk]     = useState(false)
  const [saving, setSaving] = useState(false)
  const set = (k,v) => setForm(f=>({...f,[k]:v}))

  const submit = async e => {
    e.preventDefault(); setSaving(true)
    try { await tipsApi.submit(form); setOk(true) } catch {} finally { setSaving(false) }
  }

  if (ok) return (
    <div className="card" style={{textAlign:'center',padding:'48px 40px'}}>
      <div style={{fontSize:48,marginBottom:16}}>✅</div>
      <div style={{fontSize:18,fontWeight:700,color:'var(--white)',marginBottom:8}}>Tip Submitted Anonymously</div>
      <p style={{color:'var(--ink3)',marginBottom:20}}>Your tip has been forwarded to the relevant station. No identifying information was recorded.</p>
      <button className="btn btn-primary" onClick={()=>{setOk(false);setForm({content:'',category:'',location:''})}}>Submit Another Tip</button>
    </div>
  )

  return (
    <div>
      <div className="page-header"><div><div className="page-title">Submit Anonymous Tip</div><div className="page-sub">Your identity is not recorded · No login required to use this feature publicly</div></div></div>
      <div className="alert alert-info"><span className="alert-icon">🔒</span><div>This form is completely anonymous. Your IP address and identity are <strong>not stored</strong>. Tips are reviewed by officers only.</div></div>
      <div className="card">
        <form onSubmit={submit}>
          <div className="form-group">
            <label className="form-label">Category</label>
            <select className="form-select" value={form.category} onChange={e=>set('category',e.target.value)}>
              <option value="">Select…</option>
              <option value="THEFT">Theft / Robbery</option>
              <option value="DRUGS">Drug Trafficking</option>
              <option value="CORRUPTION">Corruption</option>
              <option value="TERRORISM">Terrorism / Security Threat</option>
              <option value="MISSING">Missing Person</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div className="form-group"><label className="form-label">Location (optional)</label><input className="form-input" value={form.location} onChange={e=>set('location',e.target.value)} placeholder="Area or address relevant to the tip"/></div>
          <div className="form-group">
            <label className="form-label">Tip Details <span className="req">*</span></label>
            <textarea className="form-textarea" rows={6} required value={form.content} onChange={e=>set('content',e.target.value)} placeholder="Describe what you know. Be as specific as possible — names, times, vehicles, locations help officers act quickly."/>
          </div>
          <button type="submit" className="btn btn-primary" disabled={saving||!form.content}>{saving?'Submitting…':'Submit Tip Anonymously'}</button>
        </form>
      </div>
    </div>
  )
}
EOF

echo "All pages written."
