#!/bin/bash
FRONT=/var/www/policeconnect/frontend/src

# ── api/index.js ──────────────────────────────────────────────────────────────
cat > $FRONT/api/index.js << 'EOF'
import axios from 'axios'
const api = axios.create({ baseURL: '/api/v1', headers: { 'Content-Type': 'application/json' } })
api.interceptors.request.use(cfg => {
  const t = localStorage.getItem('access')
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})
api.interceptors.response.use(r => r, async err => {
  const orig = err.config
  if (err.response?.status === 401 && !orig._retry) {
    orig._retry = true
    const refresh = localStorage.getItem('refresh')
    if (refresh) {
      try {
        const { data } = await axios.post('/api/v1/auth/token/refresh/', { refresh })
        localStorage.setItem('access', data.access)
        orig.headers.Authorization = `Bearer ${data.access}`
        return api(orig)
      } catch { localStorage.clear(); window.location.href = '/login' }
    }
  }
  return Promise.reject(err)
})
export const authApi = {
  login:   d => api.post('/auth/login/', d),
  logout:  d => api.post('/auth/logout/', d),
  me:      () => api.get('/auth/me/'),
  register:d => api.post('/auth/register/', d),
}
export const casesApi = {
  list:         p => api.get('/cases/', { params: p }),
  get:          id => api.get(`/cases/${id}/`),
  create:       d => api.post('/cases/', d),
  updateStatus: (id, d) => api.post(`/cases/${id}/update_status/`, d),
  assignOfficer:(id, d) => api.post(`/cases/${id}/assign_officer/`, d),
  myQueue:      () => api.get('/cases/my_queue/'),
  unassigned:   () => api.get('/cases/unassigned/'),
}
export const evidenceApi = {
  list:   caseId => api.get('/evidence/', { params: { case: caseId } }),
  upload: fd => api.post('/evidence/', fd, { headers: { 'Content-Type': 'multipart/form-data' } }),
}
export const messagingApi = {
  list: caseId => api.get('/messages/', { params: { case: caseId } }),
  send: d => api.post('/messages/', d),
}
export const auditApi = { list: () => api.get('/audit/') }
export const stationsApi = { list: () => api.get('/stations/') }
export const analyticsApi = { overview: () => api.get('/analytics/overview/') }
export const certificatesApi = {
  list:   () => api.get('/certificates/'),
  create: d => api.post('/certificates/', d),
  review: (id, d) => api.post(`/certificates/${id}/review/`, d),
}
export const tipsApi = { submit: d => api.post('/tips/', d) }
export default api
EOF

# ── store/auth.js ─────────────────────────────────────────────────────────────
cat > $FRONT/store/auth.js << 'EOF'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { authApi } from '../api'
export const useAuth = create(persist((set, get) => ({
  access: null, refresh: null, profile: null,
  login: async (email, password) => {
    const { data } = await authApi.login({ email, password })
    localStorage.setItem('access', data.access)
    localStorage.setItem('refresh', data.refresh)
    set({ access: data.access, refresh: data.refresh, profile: data.profile })
    return data.profile
  },
  logout: async () => {
    try { await authApi.logout({ refresh: get().refresh }) } catch {}
    localStorage.clear()
    set({ access: null, refresh: null, profile: null })
  },
  isAuth:         () => !!(get().access || localStorage.getItem('access')),
  isCitizen:      () => get().profile?.role === 'CITIZEN',
  isOfficer:      () => ['OFFICER'].includes(get().profile?.role),
  isAdmin:        () => get().profile?.role === 'STATION_ADMIN',
  isRPC:          () => get().profile?.role === 'RPC',
  isOversight:    () => get().profile?.role === 'OVERSIGHT',
  isStaff:        () => ['OFFICER','STATION_ADMIN','RPC','OVERSIGHT'].includes(get().profile?.role),
}), {
  name: 'pc-auth',
  onRehydrateStorage: () => state => {
    if (state?.access) localStorage.setItem('access', state.access)
    if (state?.refresh) localStorage.setItem('refresh', state.refresh)
  }
}))
EOF

# ── components/Icons.jsx ──────────────────────────────────────────────────────
cat > $FRONT/components/Icons.jsx << 'EOF'
const I = ({d,className}) => <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={d}/></svg>
export const HomeIcon    = p => <I {...p} d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 22V12h6v10"/>
export const PlusIcon    = p => <I {...p} d="M12 5v14M5 12h14"/>
export const SearchIcon  = p => <I {...p} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0"/>
export const MsgIcon     = p => <I {...p} d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
export const QueueIcon   = p => <I {...p} d="M9 11l3 3L22 4 M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>
export const AdminIcon   = p => <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
export const EyeIcon     = p => <I {...p} d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 100 6 3 3 0 000-6z"/>
export const AuditIcon   = p => <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
export const ChartIcon   = p => <I {...p} d="M18 20V10M12 20V4M6 20v-6"/>
export const CertIcon    = p => <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
export const TipIcon     = p => <I {...p} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z"/>
export const ShieldIcon  = p => <I {...p} d="M12 2L3 7v6c0 5.25 3.75 10.15 9 11.25C17.25 23.15 21 18.25 21 13V7L12 2z"/>
EOF

# ── components/Sidebar.jsx ────────────────────────────────────────────────────
cat > $FRONT/components/Sidebar.jsx << 'EOF'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../store/auth'
import { HomeIcon,PlusIcon,SearchIcon,MsgIcon,QueueIcon,AdminIcon,EyeIcon,AuditIcon,ChartIcon,CertIcon,TipIcon,ShieldIcon } from './Icons'

const ROLES = {
  CITIZEN:      { label:'Citizen',        color:'var(--gold)',  bg:'rgba(252,220,4,0.12)' },
  OFFICER:      { label:'Police Officer', color:'var(--green)', bg:'var(--green-bg)' },
  STATION_ADMIN:{ label:'Station Admin',  color:'var(--blue)',  bg:'var(--blue-bg)' },
  RPC:          { label:'RPC',            color:'#a07ee0',      bg:'rgba(160,126,224,0.12)' },
  OVERSIGHT:    { label:'Oversight',      color:'var(--red)',   bg:'var(--red-bg)' },
}
const NAV = [
  { section:'Main', items:[
    { path:'/',           label:'Dashboard',       Icon:HomeIcon,  roles:['CITIZEN','OFFICER','STATION_ADMIN','RPC','OVERSIGHT'] },
    { path:'/cases/new',  label:'File New Case',   Icon:PlusIcon,  roles:['CITIZEN'] },
    { path:'/track',      label:'Track Cases',     Icon:SearchIcon,roles:['CITIZEN'] },
    { path:'/messages',   label:'Messages',        Icon:MsgIcon,   roles:['CITIZEN','OFFICER','STATION_ADMIN','RPC','OVERSIGHT'] },
    { path:'/tips',       label:'Submit Tip',      Icon:TipIcon,   roles:['CITIZEN'] },
    { path:'/certificates',label:'Conduct Certificate',Icon:CertIcon,roles:['CITIZEN'] },
  ]},
  { section:'Operations', items:[
    { path:'/queue',      label:'Case Queue',      Icon:QueueIcon, roles:['OFFICER'] },
    { path:'/admin',      label:'Station Admin',   Icon:AdminIcon, roles:['STATION_ADMIN','RPC'] },
    { path:'/oversight',  label:'Oversight',       Icon:EyeIcon,   roles:['OVERSIGHT'] },
    { path:'/audit',      label:'Audit Logs',      Icon:AuditIcon, roles:['STATION_ADMIN','RPC','OVERSIGHT'] },
    { path:'/analytics',  label:'Analytics',       Icon:ChartIcon, roles:['RPC','OVERSIGHT'] },
    { path:'/certificates/admin',label:'Certificates',Icon:CertIcon,roles:['STATION_ADMIN','RPC','OVERSIGHT'] },
  ]},
]

export default function Sidebar() {
  const { profile, logout } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const role = profile?.role || 'CITIZEN'
  const cfg  = ROLES[role] || ROLES.CITIZEN
  const init = profile ? `${profile.full_name?.[0]||''}` : '?'

  return (
    <div className="sidebar">
      <div className="flag-bar">
        <span style={{background:'#1a1a1a'}}/><span style={{background:'#FCDC04'}}/>
        <span style={{background:'#D21034'}}/><span style={{background:'#1a1a1a'}}/>
        <span style={{background:'#FCDC04'}}/><span style={{background:'#D21034'}}/>
      </div>
      <div className="logo">
        <div className="logo-shield"><ShieldIcon style={{width:20,height:20,fill:'white',stroke:'none'}}/></div>
        <div><div className="logo-text">PoliceConnect UG</div><div className="logo-sub">Uganda Police Force</div></div>
      </div>
      <div className="role-badge" style={{background:cfg.bg,color:cfg.color}}>
        <span className="role-dot" style={{background:cfg.color}}/>
        {cfg.label}
      </div>
      <div className="nav-section">
        {NAV.map(group => {
          const vis = group.items.filter(i => i.roles.includes(role))
          if (!vis.length) return null
          return (
            <div key={group.section}>
              <div className="nav-label">{group.section}</div>
              {vis.map(item => (
                <div key={item.path} className={`nav-item${loc.pathname===item.path?' active':''}`} onClick={()=>nav(item.path)}>
                  <item.Icon className="nav-icon"/>
                  {item.label}
                </div>
              ))}
            </div>
          )
        })}
      </div>
      <div className="sidebar-footer">
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
          <div style={{width:30,height:30,borderRadius:'50%',background:cfg.bg,color:cfg.color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,flexShrink:0}}>{init}</div>
          <div>
            <div style={{fontSize:12,fontWeight:600,color:'var(--white)',lineHeight:1.3}}>{profile?.full_name||'User'}</div>
            <div style={{fontSize:10,color:'var(--ink3)'}}>{profile?.email}</div>
          </div>
        </div>
        <button className="btn btn-secondary btn-sm" style={{width:'100%',justifyContent:'center'}} onClick={logout}>Sign Out</button>
      </div>
    </div>
  )
}
EOF

# ── App.jsx ───────────────────────────────────────────────────────────────────
cat > $FRONT/App.jsx << 'EOF'
import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom'
import { useAuth } from './store/auth'
import Sidebar from './components/Sidebar'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import FileCasePage from './pages/FileCasePage'
import TrackPage from './pages/TrackPage'
import MessagesPage from './pages/MessagesPage'
import OfficerQueuePage from './pages/OfficerQueuePage'
import AdminPage from './pages/AdminPage'
import OversightPage from './pages/OversightPage'
import AuditPage from './pages/AuditPage'
import AnalyticsPage from './pages/AnalyticsPage'
import CertificatesPage from './pages/CertificatesPage'
import TipsPage from './pages/TipsPage'

function RequireAuth() {
  const isAuth = useAuth(s => s.isAuth)
  return isAuth() ? <Outlet/> : <Navigate to="/login" replace/>
}
function RequireRole({ roles }) {
  const profile = useAuth(s => s.profile)
  return roles.includes(profile?.role) ? <Outlet/> : <Navigate to="/" replace/>
}
function Layout() {
  return (
    <div className="shell">
      <Sidebar/>
      <main className="main"><Outlet/></main>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login"    element={<LoginPage/>}/>
        <Route path="/register" element={<RegisterPage/>}/>
        <Route element={<RequireAuth/>}>
          <Route element={<Layout/>}>
            <Route path="/"             element={<DashboardPage/>}/>
            <Route path="/cases/new"    element={<FileCasePage/>}/>
            <Route path="/track"        element={<TrackPage/>}/>
            <Route path="/messages"     element={<MessagesPage/>}/>
            <Route path="/tips"         element={<TipsPage/>}/>
            <Route path="/certificates" element={<CertificatesPage/>}/>
            <Route element={<RequireRole roles={['OFFICER']}/>}>
              <Route path="/queue" element={<OfficerQueuePage/>}/>
            </Route>
            <Route element={<RequireRole roles={['STATION_ADMIN','RPC']}/>}>
              <Route path="/admin" element={<AdminPage/>}/>
              <Route path="/certificates/admin" element={<CertificatesPage admin/>}/>
            </Route>
            <Route element={<RequireRole roles={['OVERSIGHT']}/>}>
              <Route path="/oversight" element={<OversightPage/>}/>
            </Route>
            <Route element={<RequireRole roles={['STATION_ADMIN','RPC','OVERSIGHT']}/>}>
              <Route path="/audit"     element={<AuditPage/>}/>
            </Route>
            <Route element={<RequireRole roles={['RPC','OVERSIGHT']}/>}>
              <Route path="/analytics" element={<AnalyticsPage/>}/>
            </Route>
          </Route>
        </Route>
        <Route path="*" element={<Navigate to="/" replace/>}/>
      </Routes>
    </BrowserRouter>
  )
}
EOF

echo "App scaffold written."
